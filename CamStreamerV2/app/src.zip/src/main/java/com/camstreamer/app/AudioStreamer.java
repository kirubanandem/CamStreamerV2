package com.camstreamer.app;

import android.media.*;
import java.io.*;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Captures microphone audio.
 *
 * Exposes two outputs:
 *  1. getStream()      — WAV-headered InputStream for the HTTP /audio endpoint
 *  2. PcmListener      — raw PCM callback for recording threads so they can
 *                        encode audio without opening a second AudioRecord
 *                        (which throws IllegalStateException when the mic is
 *                        already held by this class).
 */
public class AudioStreamer {

    /** Receives raw PCM Int16 LE @ SAMPLE_RATE Hz mono. */
    public interface PcmListener {
        void onPcm(byte[] buf, int len);
    }

    private AudioRecord       audioRecord;
    private volatile boolean  isRunning = false;

    private PipedOutputStream audioOut;
    private PipedInputStream  audioIn;

    private final CopyOnWriteArrayList<PcmListener> pcmListeners =
        new CopyOnWriteArrayList<>();

    public static final int SAMPLE_RATE = 16000;
    public static final int CHANNELS    = 1;
    public static final int BITS        = 16;

    private static final int BUFFER_SIZE = AudioRecord.getMinBufferSize(
        SAMPLE_RATE,
        AudioFormat.CHANNEL_IN_MONO,
        AudioFormat.ENCODING_PCM_16BIT) * 4;

    // ── PCM listener registration ─────────────────────────────────────────────

    public void addPcmListener(PcmListener l)    { pcmListeners.add(l); }
    public void removePcmListener(PcmListener l) { pcmListeners.remove(l); }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    public void start() {
        if (isRunning) return;

        try {
            audioOut = new PipedOutputStream();
            audioIn  = new PipedInputStream(audioOut, 256 * 1024);
        } catch (IOException e) { e.printStackTrace(); return; }

        audioRecord = new AudioRecord(
            MediaRecorder.AudioSource.MIC,
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            BUFFER_SIZE);

        isRunning = true;
        audioRecord.startRecording();

        new Thread(() -> {
            try {
                writeWavHeader(audioOut);
                byte[] buf = new byte[BUFFER_SIZE];
                while (isRunning) {
                    int read = audioRecord.read(buf, 0, buf.length);
                    if (read > 0) {
                        // 1. Feed the HTTP /audio WAV stream
                        try { audioOut.write(buf, 0, read); audioOut.flush(); }
                        catch (IOException ignored) {}

                        // 2. Notify any recording listeners with a copy of the PCM
                        if (!pcmListeners.isEmpty()) {
                            byte[] copy = new byte[read];
                            System.arraycopy(buf, 0, copy, 0, read);
                            for (PcmListener l : pcmListeners) {
                                try { l.onPcm(copy, read); } catch (Exception ignored) {}
                            }
                        }
                    }
                }
            } catch (Exception ignored) {}
        }, "AudioCapture").start();
    }

    // ── WAV header ────────────────────────────────────────────────────────────

    private void writeWavHeader(OutputStream out) throws IOException {
        int byteRate   = SAMPLE_RATE * CHANNELS * (BITS / 8);
        int blockAlign = CHANNELS * (BITS / 8);
        int dataSize   = Integer.MAX_VALUE;

        ByteArrayOutputStream hdr = new ByteArrayOutputStream(44);
        DataOutputStream dout = new DataOutputStream(hdr);

        dout.writeBytes("RIFF");
        writeLe32(dout, dataSize + 36);
        dout.writeBytes("WAVE");
        dout.writeBytes("fmt ");
        writeLe32(dout, 16);
        writeLe16(dout, 1);
        writeLe16(dout, CHANNELS);
        writeLe32(dout, SAMPLE_RATE);
        writeLe32(dout, byteRate);
        writeLe16(dout, blockAlign);
        writeLe16(dout, BITS);
        dout.writeBytes("data");
        writeLe32(dout, dataSize);

        out.write(hdr.toByteArray());
        out.flush();
    }

    private void writeLe16(DataOutputStream d, int v) throws IOException {
        d.write(v & 0xFF);
        d.write((v >> 8) & 0xFF);
    }

    private void writeLe32(DataOutputStream d, int v) throws IOException {
        d.write(v & 0xFF);
        d.write((v >> 8)  & 0xFF);
        d.write((v >> 16) & 0xFF);
        d.write((v >> 24) & 0xFF);
    }

    public InputStream getStream() { return audioIn; }

    public void stop() {
        isRunning = false;
        pcmListeners.clear();
        if (audioRecord != null) {
            audioRecord.stop();
            audioRecord.release();
            audioRecord = null;
        }
        try { if (audioOut != null) audioOut.close(); } catch (IOException ignored) {}
        audioOut = null;
        audioIn  = null;
    }
}
