package com.camstreamer.app;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.*;
import java.util.*;

// ── Profile data model ──────────────────────────────────────────────────────

class Profile {
    public String id;
    public String name;
    public String icon;           // emoji char stored as string
    public List<CamEntry> cameras = new ArrayList<>();

    public Profile(String id, String name, String icon) {
        this.id = id; this.name = name; this.icon = icon;
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id",   id);
        o.put("name", name);
        o.put("icon", icon);
        JSONArray arr = new JSONArray();
        for (CamEntry c : cameras) arr.put(c.toJson());
        o.put("cameras", arr);
        return o;
    }

    public static Profile fromJson(JSONObject o) throws JSONException {
        Profile p = new Profile(o.getString("id"), o.getString("name"), o.getString("icon"));
        JSONArray arr = o.optJSONArray("cameras");
        if (arr != null) {
            for (int i = 0; i < arr.length(); i++) {
                p.cameras.add(CamEntry.fromJson(arr.getJSONObject(i)));
            }
        }
        return p;
    }
}

// ── Camera entry within a profile ──────────────────────────────────────────

class CamEntry {
    public String id;
    public String label;
    public String streamUrl;     // e.g. http://100.78.113.40:8080/video
    public String password;      // auth password for this specific camera
    public String controlBase;  // e.g. http://100.78.113.40:8080  (for /flash, /zoom etc)
    public boolean motionAlerts;

    public CamEntry(String id, String label, String streamUrl, String password, String controlBase, boolean motionAlerts) {
        this.id           = id;
        this.label        = label;
        this.streamUrl    = streamUrl;
        this.password     = password;
        this.controlBase  = controlBase;
        this.motionAlerts = motionAlerts;
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id",           id);
        o.put("label",        label);
        o.put("streamUrl",    streamUrl);
        o.put("password",     password);
        o.put("controlBase",  controlBase);
        o.put("motionAlerts", motionAlerts);
        return o;
    }

    public static CamEntry fromJson(JSONObject o) throws JSONException {
        return new CamEntry(
            o.getString("id"),
            o.getString("label"),
            o.getString("streamUrl"),
            o.optString("password", ""),
            o.optString("controlBase", ""),
            o.optBoolean("motionAlerts", false)
        );
    }
}

// ── ProfileManager — load / save profiles ──────────────────────────────────

public class ProfileManager {

    private static final String PREF_FILE    = "camstreamer_viewer_prefs";
    private static final String PREF_SERVER  = "camstreamer_prefs";       // server-side prefs
    private static final String KEY_PROFILES = "profiles";
    private static final String KEY_ACTIVE   = "active_profile";
    private static final String KEY_PASSWORD = "stream_password";         // server stream password

    private final SharedPreferences prefs;
    private final SharedPreferences serverPrefs;

    public ProfileManager(Context ctx) {
        prefs       = ctx.getSharedPreferences(PREF_FILE,   Context.MODE_PRIVATE);
        serverPrefs = ctx.getSharedPreferences(PREF_SERVER, Context.MODE_PRIVATE);
    }

    // ── Server stream password (used by MainActivity / StreamingService) ──────
    public String  getPassword()         { return serverPrefs.getString(KEY_PASSWORD, ""); }
    public void    setPassword(String pw){ serverPrefs.edit().putString(KEY_PASSWORD, pw).commit(); }
    public boolean hasPassword()         { return !getPassword().isEmpty(); }

    public synchronized List<Profile> loadAll() {
        List<Profile> list = new ArrayList<>();
        String json = prefs.getString(KEY_PROFILES, null);
        if (json == null || json.isEmpty()) return list;
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                list.add(Profile.fromJson(arr.getJSONObject(i)));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return list;
    }

    public synchronized boolean saveAll(List<Profile> profiles) {
        try {
            JSONArray arr = new JSONArray();
            for (Profile p : profiles) {
                arr.put(p.toJson());
            }
            return prefs.edit().putString(KEY_PROFILES, arr.toString()).commit();
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public synchronized void saveProfile(Profile profile) {
        List<Profile> all = loadAll();
        boolean found = false;
        for (int i = 0; i < all.size(); i++) {
            if (all.get(i).id.equals(profile.id)) {
                all.set(i, profile);
                found = true;
                break;
            }
        }
        if (!found) {
            all.add(profile);
        }
        saveAll(all);
    }

    public synchronized void deleteProfile(String id) {
        List<Profile> all = loadAll();
        Iterator<Profile> it = all.iterator();
        while (it.hasNext()) {
            if (it.next().id.equals(id)) {
                it.remove();
                break;
            }
        }
        saveAll(all);
    }

    public String getActiveProfileId() {
        return prefs.getString(KEY_ACTIVE, null);
    }

    public void setActiveProfileId(String id) {
        prefs.edit().putString(KEY_ACTIVE, id).apply();
    }

    public static String newId() { return UUID.randomUUID().toString().substring(0, 8); }
}
