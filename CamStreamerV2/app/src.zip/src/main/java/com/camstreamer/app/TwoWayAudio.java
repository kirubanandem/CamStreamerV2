package com.camstreamer.app;

import android.content.Context;
import android.media.*;
import android.util.Log;
import fi.iki.elonen.NanoHTTPD;
import fi.iki.elonen.NanoWSD;
import java.io.*;
import java.util.*;
import javax.net.ssl.SSLServerSocketFactory;

/**
 * WebSocket server — two ports:
 *   PORT_WS  (8081) plain  ws://  — LAN fallback
 *   PORT_WSS (8444) secure wss:// — used by dashboard (needed for getUserMedia in browser)
 *
 * Both accept PCM Int16 @ 16kHz mono from the viewer's Hold-to-Talk button
 * and play it through the CCTV phone LOUDSPEAKER (not the earpiece).
 *
 * Fix applied: AudioAttributes changed from USAGE_VOICE_COMMUNICATION (earpiece)
 * to USAGE_MEDIA (loudspeaker), and AudioManager forces speakerphone mode
 * while a client is connected so the audio is always audible from across a room.
 */
public class TwoWayAudio extends NanoWSD {

    private static final String TAG = "TwoWayAudio";

    private final Context    context;
    private final int        wssPort;
    private final AudioManager audioManager;

    private AudioTrack audioTrack;
    private NanoWSD    wssServer;

    private final List<WebSocket> connectedClients =
        Collections.synchronizedList(new ArrayList<>());

    private static final int SAMPLE_RATE = AudioStreamer.SAMPLE_RATE;
    private static final int BUFFER_SIZE = AudioTrack.getMinBufferSize(
        SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT) * 4;

    public TwoWayAudio(int wsPort, int wssPort, Context context) {
        super(wsPort);
        this.wssPort       = wssPort;
        this.context       = context;
        this.audioManager  = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        initAudioTrack();
    }

    private void initAudioTrack() {
        try {
            // USAGE_MEDIA routes to the loudspeaker; USAGE_VOICE_COMMUNICATION routes to earpiece.
            audioTrack = new AudioTrack(
                new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build(),
                new AudioFormat.Builder()
                    .setSampleRate(SAMPLE_RATE)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build(),
                BUFFER_SIZE,
                AudioTrack.MODE_STREAM,
                AudioManager.AUDIO_SESSION_ID_GENERATE);
            audioTrack.play();
        } catch (Exception e) {
            Log.e(TAG, "AudioTrack init failed", e);
            audioTrack = null;
        }
    }

    /** Force the device speaker to be active so audio is heard across the room. */
    private void enableSpeaker(boolean on) {
        try {
            if (on) {
                audioManager.setMode(AudioManager.MODE_NORMAL);
                audioManager.setSpeakerphoneOn(true);
            } else {
                // Only restore if no other clients remain
                if (connectedClients.isEmpty()) {
                    audioManager.setSpeakerphoneOn(false);
                    audioManager.setMode(AudioManager.MODE_NORMAL);
                }
            }
        } catch (Exception e) {
            Log.w(TAG, "Speaker toggle failed", e);
        }
    }

    @Override
    protected WebSocket openWebSocket(IHTTPSession session) {
        return new AudioWebSocket(session);
    }

    public void start() {
        try { start(NanoHTTPD.SOCKET_READ_TIMEOUT, false); }
        catch (IOException e) { Log.e(TAG, "WS start failed", e); }
        startWssServer();
    }

    private void startWssServer() {
        SSLServerSocketFactory sslFactory = SslHelper.getFactory(context);
        if (sslFactory == null) {
            Log.e(TAG, "SSL factory null — WSS will not start");
            return;
        }
        wssServer = new NanoWSD(wssPort) {
            @Override
            protected WebSocket openWebSocket(IHTTPSession session) {
                return new AudioWebSocket(session);
            }
        };
        try {
            wssServer.makeSecure(sslFactory, null);
            wssServer.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false);
            Log.i(TAG, "WSS server started on port " + wssPort);
        } catch (IOException e) {
            Log.e(TAG, "WSS server failed to start: " + e.getMessage(), e);
        }
    }

    public void stop() {
        super.stop();
        if (wssServer != null) { wssServer.stop(); wssServer = null; }
        if (audioTrack != null) {
            try { audioTrack.stop(); audioTrack.release(); } catch (Exception ignored) {}
            audioTrack = null;
        }
        // Restore audio mode
        try {
            audioManager.setSpeakerphoneOn(false);
            audioManager.setMode(AudioManager.MODE_NORMAL);
        } catch (Exception ignored) {}
    }

    public int getClientCount() { return connectedClients.size(); }

    // ── WebSocket handler ─────────────────────────────────────────────────────

    private class AudioWebSocket extends WebSocket {

        AudioWebSocket(IHTTPSession handshake) { super(handshake); }

        @Override
        protected void onOpen() {
            connectedClients.add(this);
            enableSpeaker(true);   // activate loudspeaker when a client connects
        }

        @Override
        protected void onClose(WebSocketFrame.CloseCode code, String reason, boolean byRemote) {
            connectedClients.remove(this);
            enableSpeaker(false);  // may restore if no other clients
        }

        @Override
        protected void onMessage(WebSocketFrame msg) {
            byte[] payload = msg.getBinaryPayload();
            if (payload != null && payload.length > 0 && audioTrack != null) {
                try { audioTrack.write(payload, 0, payload.length); }
                catch (Exception e) { Log.w(TAG, "AudioTrack write error", e); }
            }
        }

        @Override protected void onPong(WebSocketFrame pong) {}

        @Override
        protected void onException(IOException ex) {
            connectedClients.remove(this);
            enableSpeaker(false);
        }
    }
}
