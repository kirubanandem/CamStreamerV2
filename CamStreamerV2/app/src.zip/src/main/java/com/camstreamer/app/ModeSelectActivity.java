package com.camstreamer.app;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import java.util.ArrayList;
import java.util.List;

/**
 * Entry point — runs a compatibility check before letting the user choose a mode.
 * Shows a clear, human-readable error for every possible reason the app
 * might fail to install or run on this device.
 */
public class ModeSelectActivity extends AppCompatActivity {

    private static final int REQ_PERMISSIONS = 200;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_mode_select);

        Button btnServer = findViewById(R.id.btnServerMode);
        Button btnViewer = findViewById(R.id.btnViewerMode);

        if (btnServer != null) btnServer.setOnClickListener(v -> {
            if (checkCompatibilityForServer()) {
                startActivity(new Intent(this, MainActivity.class));
            }
        });

        if (btnViewer != null) btnViewer.setOnClickListener(v ->
            startActivity(new Intent(this, ViewerActivity.class)));

        // Run check once on launch and show any warnings as a banner
        runStartupCheck();
    }

    // ── Startup check — runs silently, shows banner only if critical issues found ──

    private void runStartupCheck() {
        List<String> issues = new ArrayList<>();

        // Android version check
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            issues.add("Android 8.0 (Oreo) or higher is required. This device runs Android "
                + Build.VERSION.RELEASE + ".");
        }

        // Camera hardware check
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY)) {
            issues.add("No camera detected on this device. Server mode will not work.");
        }

        // Microphone check
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_MICROPHONE)) {
            issues.add("No microphone detected. Audio streaming will not work.");
        }

        // Network/Internet check
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_WIFI)
                && !getPackageManager().hasSystemFeature("android.hardware.ethernet")) {
            issues.add("No Wi-Fi adapter detected. The app requires a network connection.");
        }

        if (!issues.isEmpty()) {
            showIssueDialog("Device Compatibility Warning",
                String.join("\n\n", issues), false);
        }
    }

    // ── Full check before entering Server mode ────────────────────────────────

    private boolean checkCompatibilityForServer() {
        List<String> blockers  = new ArrayList<>();
        List<String> warnings  = new ArrayList<>();

        // ── Hard blockers — app cannot function without these ──────────────────

        // Android version
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            blockers.add("❌  Android 8.0+ required\n"
                + "    This device runs Android " + Build.VERSION.RELEASE
                + ". Please upgrade to Android 8.0 (Oreo) or later.");
        }

        // Camera permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            blockers.add("❌  Camera permission not granted\n"
                + "    Go to: Settings → Apps → CamStreamer → Permissions → Camera → Allow");
        }

        // Microphone permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            blockers.add("❌  Microphone permission not granted\n"
                + "    Go to: Settings → Apps → CamStreamer → Permissions → Microphone → Allow");
        }

        // Camera hardware
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY)) {
            blockers.add("❌  No camera found on this device\n"
                + "    Server mode requires a physical camera to stream video.");
        }

        // Check camera2 API is available
        CameraManager cm = (CameraManager) getSystemService(CAMERA_SERVICE);
        try {
            if (cm == null || cm.getCameraIdList().length == 0) {
                blockers.add("❌  Camera2 API unavailable\n"
                    + "    This device's camera driver is not compatible. "
                    + "Try a different Android device.");
            }
        } catch (CameraAccessException e) {
            blockers.add("❌  Camera access error: " + e.getMessage() + "\n"
                + "    Another app may be using the camera. Close other camera apps and try again.");
        }

        // ── Soft warnings — app will work but with reduced functionality ───────

        // Notification permission (Android 13+)
        if (Build.VERSION.SDK_INT >= 33
                && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            warnings.add("⚠️  Notification permission not granted\n"
                + "    Motion detection alerts will not appear as notifications.\n"
                + "    Go to: Settings → Apps → CamStreamer → Permissions → Notifications → Allow");
        }

        // Storage permission (Android 9 and below)
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P
                && ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            warnings.add("⚠️  Storage permission not granted\n"
                + "    Video recording to the Movies folder will not work.\n"
                + "    Go to: Settings → Apps → CamStreamer → Permissions → Storage → Allow");
        }

        // Flash / torch
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH)) {
            warnings.add("⚠️  No camera flash/torch on this device\n"
                + "    Torch and Auto Flash modes will be disabled.");
        }

        // Low RAM warning (less than 512MB available)
        long freeMem = Runtime.getRuntime().freeMemory() / (1024 * 1024);
        if (freeMem < 80) {
            warnings.add("⚠️  Low memory (" + freeMem + " MB free)\n"
                + "    The stream may be unstable. Close background apps before starting.");
        }

        // If there are hard blockers, show them and block entry
        if (!blockers.isEmpty()) {
            StringBuilder msg = new StringBuilder();
            msg.append("The following issues must be fixed before using Server mode:\n\n");
            for (String b : blockers) msg.append(b).append("\n\n");
            if (!warnings.isEmpty()) {
                msg.append("Additionally:\n\n");
                for (String w : warnings) msg.append(w).append("\n\n");
            }
            showIssueDialog("Cannot Start Server Mode", msg.toString().trim(), true);
            return false;
        }

        // If there are only warnings, show them but allow entry
        if (!warnings.isEmpty()) {
            StringBuilder msg = new StringBuilder(
                "Server mode will start, but note the following:\n\n");
            for (String w : warnings) msg.append(w).append("\n\n");
            showWarningThenProceed("Warnings", msg.toString().trim(),
                new Intent(this, MainActivity.class));
            return false; // dialog handles navigation
        }

        return true; // all clear
    }

    // ── Dialog helpers ────────────────────────────────────────────────────────

    private void showIssueDialog(String title, String message, boolean offerSettings) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("OK", null);

        if (offerSettings) {
            builder.setNeutralButton("Open App Settings", (d, w) -> {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                i.setData(Uri.parse("package:" + getPackageName()));
                startActivity(i);
            });
        }
        builder.show();
    }

    private void showWarningThenProceed(String title, String message, Intent next) {
        new AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Continue Anyway", (d, w) -> startActivity(next))
            .setNegativeButton("Fix Issues", (d, w) -> {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                i.setData(Uri.parse("package:" + getPackageName()));
                startActivity(i);
            })
            .show();
    }

    // ── Request permissions on first launch ───────────────────────────────────

    @Override
    protected void onResume() {
        super.onResume();
        // Request permissions if not yet granted (first launch)
        List<String> needed = new ArrayList<>();
        needed.add(Manifest.permission.CAMERA);
        needed.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 33)
            needed.add(Manifest.permission.POST_NOTIFICATIONS);
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P)
            needed.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);

        needed.removeIf(p -> ContextCompat.checkSelfPermission(this, p)
            == PackageManager.PERMISSION_GRANTED);
        if (!needed.isEmpty())
            androidx.core.app.ActivityCompat.requestPermissions(
                this, needed.toArray(new String[0]), REQ_PERMISSIONS);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
            String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_PERMISSIONS) return;

        List<String> denied = new ArrayList<>();
        List<String> permanent = new ArrayList<>();

        for (int i = 0; i < permissions.length; i++) {
            if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                String friendly = friendlyPermissionName(permissions[i]);
                boolean isPermanent = !androidx.core.app.ActivityCompat
                    .shouldShowRequestPermissionRationale(this, permissions[i]);
                if (isPermanent) permanent.add(friendly);
                else denied.add(friendly);
            }
        }

        if (denied.isEmpty() && permanent.isEmpty()) return;

        StringBuilder msg = new StringBuilder();

        if (!permanent.isEmpty()) {
            msg.append("The following permissions were permanently denied "
                + "(you selected 'Don't ask again'):\n\n");
            for (String p : permanent)
                msg.append("• ").append(p).append("\n");
            msg.append("\nTo fix this:\n"
                + "  Settings → Apps → CamStreamer → Permissions\n"
                + "  Then allow each permission listed above.\n\n");
        }

        if (!denied.isEmpty()) {
            msg.append("The following permissions were denied:\n\n");
            for (String d : denied)
                msg.append("• ").append(d).append("\n");
            msg.append("\nSome features will not work without these permissions.\n"
                + "Tap the button below to grant them.");
        }

        new AlertDialog.Builder(this)
            .setTitle("Permissions Required")
            .setMessage(msg.toString().trim())
            .setPositiveButton(permanent.isEmpty() ? "Grant Permissions" : "Open Settings",
                (d, w) -> {
                    if (!permanent.isEmpty()) {
                        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                        intent.setData(Uri.parse("package:" + getPackageName()));
                        startActivity(intent);
                    } else {
                        // Re-request runtime permissions
                        List<String> retry = new ArrayList<>();
                        for (String p : permissions)
                            if (ContextCompat.checkSelfPermission(this, p)
                                    != PackageManager.PERMISSION_GRANTED)
                                retry.add(p);
                        if (!retry.isEmpty())
                            androidx.core.app.ActivityCompat.requestPermissions(
                                this, retry.toArray(new String[0]), REQ_PERMISSIONS);
                    }
                })
            .setNegativeButton("Skip", null)
            .show();
    }

    private String friendlyPermissionName(String permission) {
        switch (permission) {
            case Manifest.permission.CAMERA:
                return "Camera — needed to stream video";
            case Manifest.permission.RECORD_AUDIO:
                return "Microphone — needed for audio streaming and two-way talk";
            case Manifest.permission.POST_NOTIFICATIONS:
                return "Notifications — needed for motion detection alerts";
            case Manifest.permission.WRITE_EXTERNAL_STORAGE:
                return "Storage — needed to save recorded video files";
            default:
                return permission.replace("android.permission.", "");
        }
    }
}
