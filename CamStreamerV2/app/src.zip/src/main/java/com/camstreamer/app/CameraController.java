package com.camstreamer.app;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.*;
import android.hardware.camera2.*;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.ImageReader;
import android.os.*;
import android.util.*;
import android.view.Surface;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

/**
 * Camera2 wrapper.
 *
 * Timestamp overlay
 * ─────────────────
 * Every JPEG frame arriving in onImageAvailable() is decoded to a Bitmap,
 * the current date/time is drawn onto it in CCTV style (bottom-left, white
 * text with a semi-transparent black backing strip), then re-encoded to JPEG
 * and stored as latestFrame.
 *
 * This single stamp point covers:
 *   • The MJPEG web stream (reads latestFrame directly)
 *   • The recording path that re-encodes stamped frames via MediaCodec
 *
 * The MediaRecorder-from-Surface path bypasses latestFrame entirely and
 * therefore gets unstamped frames from the hardware ISP.  StreamingService
 * detects this and routes recording through the stamped-frame MediaCodec
 * path instead (see StreamingService.startRecording).
 */
public class CameraController {

    public static final int FLASH_OFF   = 0;
    public static final int FLASH_TORCH = 1;
    public static final int FLASH_AUTO  = 2;

    private final Context        context;
    private final MotionDetector motionDetector;
    private final CameraManager  cameraManager;

    private boolean useFrontCamera = false;
    private int     qualityIndex   = 1;
    private int     fps            = 15;
    private int     flashMode      = FLASH_OFF;
    private float   zoomLevel      = 1.0f;
    private boolean nightMode      = false;

    private CameraDevice           cameraDevice;
    private CameraCaptureSession   captureSession;
    private CaptureRequest.Builder previewBuilder;
    private ImageReader            imageReader;
    private HandlerThread          cameraThread;
    private Handler                cameraHandler;
    private final Semaphore        cameraLock = new Semaphore(1);

    /** Optional extra surface (MediaRecorder input) — wired into capture session. */
    private Surface recorderSurface = null;

    private String selectedCameraId = null;

    private volatile byte[] latestFrame   = new byte[0];
    private final Object    frameLock     = new Object();
    private volatile boolean cameraRunning = false;

    // ── Timestamp overlay paint objects (created once, reused every frame) ────
    private final Paint   stampTextPaint;
    private final Paint   stampBgPaint;
    private final SimpleDateFormat stampFmt =
        new SimpleDateFormat("yyyy-MM-dd  HH:mm:ss", Locale.US);

    private static final int[][] RESOLUTIONS = {
        {640, 480}, {1280, 720}, {1920, 1080}
    };

    public CameraController(Context context, MotionDetector md) {
        this.context        = context;
        this.motionDetector = md;
        this.cameraManager  = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);

        // ── Timestamp paint setup ─────────────────────────────────────────────
        // Text: white, monospace so digits don't jitter, size scales with frame
        stampTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        stampTextPaint.setColor(Color.WHITE);
        stampTextPaint.setTextSize(28f);           // will be rescaled per frame
        stampTextPaint.setTypeface(Typeface.MONOSPACE);
        stampTextPaint.setStyle(Paint.Style.FILL);

        // Background: semi-transparent black strip behind text
        stampBgPaint = new Paint();
        stampBgPaint.setColor(Color.argb(160, 0, 0, 0));
        stampBgPaint.setStyle(Paint.Style.FILL);
    }

    // ── Recorder surface ──────────────────────────────────────────────────────

    public void setRecorderSurface(Surface surface) {
        recorderSurface = surface;
        if (cameraRunning) restartCamera();
    }

    public void clearRecorderSurface() {
        recorderSurface = null;
        if (cameraRunning) restartCamera();
    }

    // ── Setters ───────────────────────────────────────────────────────────────

    public void switchCamera(boolean front)  { useFrontCamera = front; if (cameraRunning) restartCamera(); }
    public void setQuality(int idx)          { if (qualityIndex != idx) { qualityIndex = idx; if (cameraRunning) restartCamera(); } }
    public void setFps(int f)                { fps = f; applyRepeatingRequest(); }
    public void setFlashMode(int m)          { flashMode = m; applyRepeatingRequest(); }
    public void setZoom(float z)             { zoomLevel = z; applyRepeatingRequest(); }
    public void setNightMode(boolean on)     { nightMode = on; applyRepeatingRequest(); }

    // ── Getters ───────────────────────────────────────────────────────────────

    public boolean isFrontCamera()   { return useFrontCamera; }
    public int     getQualityIndex() { return qualityIndex; }
    public int     getFps()          { return fps; }
    public int     getFlashMode()    { return flashMode; }
    public float   getZoomLevel()    { return zoomLevel; }
    public boolean isNightMode()     { return nightMode; }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    public void startCamera() {
        if (cameraRunning) return;
        cameraThread = new HandlerThread("CamThread");
        cameraThread.start();
        cameraHandler = new Handler(cameraThread.getLooper());
        cameraRunning = true;
        openCamera();
    }

    public void stopCamera() {
        cameraRunning = false;
        closeCamera();
        if (cameraThread != null) {
            cameraThread.quitSafely();
            try { cameraThread.join(1000); } catch (InterruptedException ignored) {}
            cameraThread = null;
        }
        selectedCameraId = null;
    }

    public void release() { stopCamera(); }

    private void restartCamera() {
        if (!cameraRunning) return;
        selectedCameraId = null;
        closeCamera();
        openCamera();
    }

    private void closeCamera() {
        try { cameraLock.acquire(); } catch (InterruptedException e) { return; }
        try {
            if (captureSession != null) { captureSession.close(); captureSession = null; }
            if (cameraDevice   != null) { cameraDevice.close();   cameraDevice   = null; }
            if (imageReader    != null) { imageReader.close();     imageReader    = null; }
        } finally { cameraLock.release(); }
    }

    @SuppressLint("MissingPermission")
    private void openCamera() {
        if (cameraHandler == null) {
            cameraThread = new HandlerThread("CamThread");
            cameraThread.start();
            cameraHandler = new Handler(cameraThread.getLooper());
        }
        try {
            if (!cameraLock.tryAcquire(2500, TimeUnit.MILLISECONDS)) return;

            selectedCameraId = getCameraId();
            int w = RESOLUTIONS[qualityIndex][0], h = RESOLUTIONS[qualityIndex][1];

            CameraCharacteristics cc = cameraManager.getCameraCharacteristics(selectedCameraId);
            StreamConfigurationMap map = cc.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            Size best = chooseBestSize(map.getOutputSizes(android.graphics.ImageFormat.JPEG), w, h);

            imageReader = ImageReader.newInstance(best.getWidth(), best.getHeight(),
                android.graphics.ImageFormat.JPEG, 3);
            imageReader.setOnImageAvailableListener(this::onImageAvailable, cameraHandler);

            cameraManager.openCamera(selectedCameraId, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice c) {
                    cameraLock.release(); cameraDevice = c; createCaptureSession();
                }
                @Override public void onDisconnected(CameraDevice c) {
                    cameraLock.release(); c.close(); cameraDevice = null;
                }
                @Override public void onError(CameraDevice c, int e) {
                    cameraLock.release(); c.close(); cameraDevice = null;
                }
            }, cameraHandler);
        } catch (Exception e) { e.printStackTrace(); cameraLock.release(); }
    }

    private void createCaptureSession() {
        try {
            List<Surface> targets = new ArrayList<>();
            targets.add(imageReader.getSurface());
            if (recorderSurface != null) targets.add(recorderSurface);

            int template = (recorderSurface != null)
                ? CameraDevice.TEMPLATE_RECORD
                : CameraDevice.TEMPLATE_PREVIEW;

            previewBuilder = cameraDevice.createCaptureRequest(template);
            for (Surface s : targets) previewBuilder.addTarget(s);

            cameraDevice.createCaptureSession(targets,
                new CameraCaptureSession.StateCallback() {
                    @Override public void onConfigured(CameraCaptureSession s) {
                        captureSession = s; applyRepeatingRequest();
                    }
                    @Override public void onConfigureFailed(CameraCaptureSession s) {}
                }, cameraHandler);
        } catch (CameraAccessException e) { e.printStackTrace(); }
    }

    private void applyRepeatingRequest() {
        if (previewBuilder == null || captureSession == null) return;
        try {
            if (nightMode) {
                previewBuilder.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_OFF);
                previewBuilder.set(CaptureRequest.SENSOR_SENSITIVITY, 3200);
                previewBuilder.set(CaptureRequest.SENSOR_EXPOSURE_TIME, 100_000_000L);
                previewBuilder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF);
            } else {
                previewBuilder.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO);
                previewBuilder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
                previewBuilder.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, new Range<>(fps, fps));
            }
            previewBuilder.set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO);
            previewBuilder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO);

            switch (flashMode) {
                case FLASH_TORCH:
                    previewBuilder.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_TORCH);
                    previewBuilder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
                    break;
                case FLASH_AUTO:
                    previewBuilder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON_AUTO_FLASH);
                    previewBuilder.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_OFF);
                    break;
                default:
                    previewBuilder.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_OFF);
                    break;
            }

            if (selectedCameraId != null) {
                CameraCharacteristics cc = cameraManager.getCameraCharacteristics(selectedCameraId);
                Rect sensor = cc.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
                if (sensor != null && zoomLevel > 1.0f) {
                    int cw = (int)(sensor.width()  / zoomLevel);
                    int ch = (int)(sensor.height() / zoomLevel);
                    int cx = (sensor.width()  - cw) / 2;
                    int cy = (sensor.height() - ch) / 2;
                    previewBuilder.set(CaptureRequest.SCALER_CROP_REGION,
                        new Rect(cx, cy, cx + cw, cy + ch));
                } else if (sensor != null) {
                    previewBuilder.set(CaptureRequest.SCALER_CROP_REGION, sensor);
                }
            }

            captureSession.setRepeatingRequest(previewBuilder.build(), null, cameraHandler);
        } catch (CameraAccessException e) { e.printStackTrace(); }
    }

    public void triggerAutoFocus() {
        if (previewBuilder == null || captureSession == null) return;
        try {
            previewBuilder.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_START);
            captureSession.capture(previewBuilder.build(), null, cameraHandler);
            previewBuilder.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_IDLE);
        } catch (CameraAccessException e) { e.printStackTrace(); }
    }

    // ── Frame arrival + timestamp overlay ────────────────────────────────────

    private void onImageAvailable(ImageReader reader) {
        android.media.Image image = reader.acquireLatestImage();
        if (image == null) return;

        ByteBuffer buf = image.getPlanes()[0].getBuffer();
        byte[] rawJpeg = new byte[buf.remaining()];
        buf.get(rawJpeg);
        image.close();

        // Burn the timestamp into the JPEG before storing
        byte[] stamped = stampTimestamp(rawJpeg);

        synchronized (frameLock) { latestFrame = stamped; frameLock.notifyAll(); }
        motionDetector.detect(stamped);
    }

    /**
     * Decode rawJpeg → Bitmap, draw CCTV-style date/time overlay, re-encode to JPEG.
     * If anything fails the original raw bytes are returned unchanged.
     */
    private byte[] stampTimestamp(byte[] rawJpeg) {
        try {
            // Decode
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
            opts.inMutable = true;
            Bitmap bmp = BitmapFactory.decodeByteArray(rawJpeg, 0, rawJpeg.length, opts);
            if (bmp == null) return rawJpeg;

            int w = bmp.getWidth();
            int h = bmp.getHeight();

            // Scale text size proportionally to frame width (28px at 640px wide)
            float textSize = Math.max(20f, w * 0.044f);
            stampTextPaint.setTextSize(textSize);

            String ts = stampFmt.format(new Date());

            // Measure text bounds
            float textW  = stampTextPaint.measureText(ts);
            float margin = textSize * 0.35f;
            float padX   = margin;
            float padY   = margin * 0.8f;
            float bgH    = textSize + padY * 2f;

            // Draw background strip at bottom-left (CCTV convention)
            Canvas canvas = new Canvas(bmp);
            canvas.drawRect(0, h - bgH, textW + padX * 2f, h, stampBgPaint);

            // Draw text — baseline sits inside the strip
            canvas.drawText(ts, padX, h - padY - stampTextPaint.descent(), stampTextPaint);

            // Re-encode to JPEG at 85% quality — good balance of size vs quality
            ByteArrayOutputStream out = new ByteArrayOutputStream(rawJpeg.length);
            bmp.compress(Bitmap.CompressFormat.JPEG, 85, out);
            bmp.recycle();

            return out.toByteArray();
        } catch (Exception e) {
            return rawJpeg; // never drop a frame — fall back to unstamped
        }
    }

    public byte[]  getLatestFrame() { synchronized (frameLock) { return latestFrame.clone(); } }
    public boolean hasFrame()       { synchronized (frameLock) { return latestFrame.length > 0; } }

    public void waitForNewFrame(long timeoutMs) {
        synchronized (frameLock) {
            try { frameLock.wait(timeoutMs); } catch (InterruptedException ignored) {}
        }
    }

    private String getCameraId() throws CameraAccessException {
        for (String id : cameraManager.getCameraIdList()) {
            CameraCharacteristics cc = cameraManager.getCameraCharacteristics(id);
            Integer facing = cc.get(CameraCharacteristics.LENS_FACING);
            if (facing == null) continue;
            if (useFrontCamera  && facing == CameraCharacteristics.LENS_FACING_FRONT) return id;
            if (!useFrontCamera && facing == CameraCharacteristics.LENS_FACING_BACK)  return id;
        }
        return cameraManager.getCameraIdList()[0];
    }

    private Size chooseBestSize(Size[] sizes, int tw, int th) {
        Size best = sizes[0]; int bestDiff = Integer.MAX_VALUE;
        for (Size s : sizes) {
            int d = Math.abs(s.getWidth()-tw) + Math.abs(s.getHeight()-th);
            if (d < bestDiff) { bestDiff = d; best = s; }
        }
        return best;
    }
}
