package com.camstreamer.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.*;
import java.util.*;

public class ViewerActivity extends AppCompatActivity {

    private ProfileManager  profileManager;
    private List<Profile>   profiles = new ArrayList<>();
    private RecyclerView    rvProfiles;
    private ProfileAdapter  adapter;
    private TextView        tvNoProfiles;

    private boolean dialogOpen = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewer);
        profileManager = new ProfileManager(this);

        rvProfiles   = findViewById(R.id.rvProfiles);
        tvNoProfiles = findViewById(R.id.tvNoProfiles);

        rvProfiles.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ProfileAdapter(
            profiles,
            this::onProfileOpen,
            this::onProfileEdit,
            this::onProfileDelete
        );
        rvProfiles.setAdapter(adapter);

        findViewById(R.id.btnAddProfile).setOnClickListener(v -> showProfileDialog(null));
    }

    @Override
    protected void onResume() {
        super.onResume();
        dialogOpen = false;
        loadProfiles();
    }

    private void loadProfiles() {
        profiles.clear();
        profiles.addAll(profileManager.loadAll());
        adapter.notifyDataSetChanged();
        boolean empty = profiles.isEmpty();
        tvNoProfiles.setVisibility(empty ? View.VISIBLE : View.GONE);
        rvProfiles.setVisibility(empty ? View.GONE   : View.VISIBLE);
    }

    private void onProfileOpen(Profile p) {
        if (dialogOpen) return;
        Intent i = new Intent(this, GridViewActivity.class);
        i.putExtra("profile_id", p.id);
        startActivity(i);
    }

    private void onProfileEdit(Profile p) {
        showProfileDialog(p);
    }

    private void onProfileDelete(Profile p) {
        if (dialogOpen) return;
        dialogOpen = true;
        new AlertDialog.Builder(this)
            .setTitle("Delete \"" + p.name + "\"?")
            .setMessage("This will remove the profile and all its cameras.")
            .setPositiveButton("Delete", (d, w) -> {
                profileManager.deleteProfile(p.id);
                loadProfiles();
            })
            .setNegativeButton("Cancel", null)
            .setOnDismissListener(d -> dialogOpen = false)
            .show();
    }

    private void showProfileDialog(Profile existing) {
        if (dialogOpen) return;
        dialogOpen = true;

        View v = getLayoutInflater().inflate(R.layout.dialog_profile, null);
        EditText etName = v.findViewById(R.id.etProfileName);
        EditText etIcon = v.findViewById(R.id.etProfileIcon);

        if (existing != null) {
            etName.setText(existing.name);
            etIcon.setText(existing.icon);
        }

        new AlertDialog.Builder(this)
            .setTitle(existing == null ? "New profile" : "Edit profile")
            .setView(v)
            .setPositiveButton("Save", (d, w) -> {
                String name = etName.getText().toString().trim();
                String icon = etIcon.getText().toString().trim();
                if (name.isEmpty()) name = "Profile";
                if (icon.isEmpty()) icon = "🏠";

                if (existing != null) {
                    existing.name = name;
                    existing.icon = icon;
                    profileManager.saveProfile(existing);
                } else {
                    Profile np = new Profile(ProfileManager.newId(), name, icon);
                    profileManager.saveProfile(np);
                }
                loadProfiles();
            })
            .setNegativeButton("Cancel", null)
            .setOnDismissListener(d -> dialogOpen = false)
            .show();
    }
}
