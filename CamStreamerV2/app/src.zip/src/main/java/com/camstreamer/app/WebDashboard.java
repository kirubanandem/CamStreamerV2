package com.camstreamer.app;

public class WebDashboard {

    public static String getHtml(String password) {
        boolean hasPassword = password != null && !password.isEmpty();
        String hp = hasPassword ? "true" : "false";
        int dvrMins = StreamingService.DVR_SEGMENT_MINUTES;
        int dvrKeep = StreamingService.DVR_KEEP_SEGMENTS * dvrMins;

        return "<!DOCTYPE html><html lang='en'><head>" +
        "<meta charset='UTF-8'><meta name='viewport' content='width=device-width,initial-scale=1'>" +
        "<title>CamStreamer</title><style>" +
        ":root{--bg:#0a0a0f;--side:#12121a;--border:#1e1e2e;--accent:#00e5a0;--accent2:#00b4ff;" +
        "--warn:#ff6b35;--red:#ff3b3b;--text:#e8e8f0;--muted:#5a5a7a;}" +
        "*{box-sizing:border-box;margin:0;padding:0;}" +
        "body{background:var(--bg);color:var(--text);font-family:'Segoe UI',system-ui,sans-serif;" +
        "display:flex;flex-direction:column;height:100vh;overflow:hidden;}" +
        "#httpsBar{display:none;background:#1a1430;border-bottom:1px solid #534ab7;" +
        "padding:7px 14px;font-size:.72rem;color:#afa9ec;text-align:center;flex-shrink:0;}" +
        "#httpsBar a{color:var(--accent2);font-weight:bold;}" +
        ".layout{display:flex;flex:1;overflow:hidden;}" +
        ".sidebar{width:310px;background:var(--side);border-right:1px solid var(--border);" +
        "padding:14px;display:flex;flex-direction:column;overflow-y:auto;flex-shrink:0;}" +
        ".sidebar h1{color:var(--accent);font-size:1rem;letter-spacing:3px;text-transform:uppercase;" +
        "margin-bottom:12px;text-align:center;border-bottom:1px solid var(--border);padding-bottom:10px;}" +
        ".main{flex-grow:1;display:flex;flex-direction:column;background:#000;overflow:hidden;}" +
        ".stream-wrap{flex-grow:1;position:relative;display:flex;align-items:center;justify-content:center;}" +
        "#streamImg{max-width:100%;max-height:100%;object-fit:contain;display:none;}" +
        "#playbackWrap{display:none;flex-direction:column;width:100%;height:100%;}" +
        "#playbackVideo{flex:1;width:100%;background:#000;}" +
        "#playbackBar{padding:8px 12px;background:#111;display:flex;align-items:center;gap:8px;flex-shrink:0;}" +
        "#playbackBar span{font-size:.7rem;color:var(--muted);flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}" +
        "#btnClosePlayback{padding:5px 12px;background:var(--red);color:#fff;border:none;border-radius:4px;" +
        "cursor:pointer;font-size:.7rem;font-family:inherit;white-space:nowrap;}" +
        ".ph{color:var(--muted);text-align:center;position:absolute;}" +
        ".card{background:rgba(255,255,255,.03);border:1px solid var(--border);border-radius:7px;padding:11px;margin-bottom:11px;}" +
        "h3{font-size:.6rem;color:var(--muted);letter-spacing:2px;text-transform:uppercase;margin-bottom:8px;}" +
        "label{font-size:.67rem;color:var(--muted);display:block;margin-bottom:3px;}" +
        "select,input[type=password]{width:100%;background:#0d0d14;border:1px solid var(--border);" +
        "color:var(--text);padding:7px 9px;border-radius:5px;font-family:inherit;font-size:.77rem;margin-bottom:8px;}" +
        "input[type=range]{width:100%;padding:3px 0;accent-color:var(--accent);margin-bottom:8px;}" +
        ".row{display:flex;gap:6px;margin-bottom:8px;}" +
        ".btn{flex:1;padding:8px 4px;border:1px solid var(--border);background:rgba(255,255,255,.04);" +
        "color:var(--text);border-radius:5px;cursor:pointer;font-size:.71rem;font-family:inherit;transition:all .15s;}" +
        ".btn:hover{border-color:var(--accent);background:rgba(0,229,160,.07);}" +
        ".btn.on{background:var(--accent);color:#000;border-color:var(--accent);font-weight:bold;}" +
        ".btn.rec.on{background:var(--red);color:#fff;border-color:var(--red);}" +
        ".btn.dvr-on{background:var(--warn);color:#000;border-color:var(--warn);font-weight:bold;}" +
        ".stream-btn{width:100%;padding:10px;margin-bottom:11px;background:var(--accent2);color:#000;" +
        "border:none;font-weight:bold;border-radius:6px;cursor:pointer;font-size:.8rem;font-family:inherit;transition:background .2s;}" +
        ".stream-btn.on{background:var(--red);color:#fff;}" +
        ".stat-row{display:flex;gap:7px;margin-bottom:11px;}" +
        ".stat{flex:1;background:rgba(0,0,0,.3);border:1px solid var(--border);border-radius:5px;padding:6px 9px;}" +
        ".stat .slabel{font-size:.58rem;color:var(--muted);margin-bottom:2px;}" +
        ".stat .sval{font-size:.78rem;font-weight:bold;font-family:monospace;}" +
        ".green{color:#44cc44;}.orange{color:#ff9944;}.red-c{color:var(--red);}" +
        ".talk-btn{width:100%;padding:11px;background:#1a1430;color:#afa9ec;" +
        "border:1px solid #534ab7;border-radius:6px;cursor:pointer;font-size:.78rem;" +
        "font-family:inherit;user-select:none;transition:all .15s;}" +
        ".talk-btn.on{background:#534ab7;color:#fff;border-color:#7f77dd;}" +
        ".ep a{color:var(--accent2);text-decoration:none;font-size:.7rem;font-family:monospace;" +
        "display:block;padding:3px 5px;border-radius:4px;background:rgba(0,180,255,.04);margin-bottom:5px;}" +
        ".ep a:hover{background:rgba(0,180,255,.1);}" +
        ".dvr-file{display:flex;align-items:center;gap:6px;padding:5px 7px;border-radius:4px;" +
        "background:rgba(255,255,255,.03);border:1px solid var(--border);margin-bottom:4px;}" +
        ".dvr-file-info{flex:1;}" +
        ".dvr-file-time{font-size:.65rem;color:var(--text);font-family:monospace;display:block;}" +
        ".dvr-file-size{font-size:.6rem;color:var(--muted);}" +
        ".dvr-play{padding:3px 9px;font-size:.63rem;border:1px solid var(--accent2);" +
        "background:rgba(0,180,255,.08);color:var(--accent2);border-radius:3px;cursor:pointer;font-family:inherit;white-space:nowrap;}" +
        ".dvr-play:hover{background:rgba(0,180,255,.2);}" +
        "#motionBanner{display:none;position:fixed;top:12px;left:50%;transform:translateX(-50%);" +
        "background:var(--red);color:#fff;font-weight:bold;padding:10px 22px;border-radius:8px;font-size:.85rem;z-index:8000;}" +
        "#loginOverlay{position:fixed;inset:0;background:rgba(10,10,15,.97);" +
        "display:flex;align-items:center;justify-content:center;z-index:9999;}" +
        "#loginBox{background:var(--side);border:1px solid var(--border);border-radius:11px;padding:30px;min-width:290px;}" +
        "@media(max-width:750px){.layout{flex-direction:column;overflow:auto;}" +
        ".sidebar{width:100%;border-right:none;border-bottom:1px solid var(--border);overflow-y:visible;}" +
        ".main{height:55vh;flex-shrink:0;}}" +
        "</style></head><body>" +

        "<div id='httpsBar'>\uD83D\uDD12 For microphone / two-way talk, use the " +
        "<a id='httpsLink' href='#'>HTTPS version on port 8443</a>. Controls and video work on either port.</div>" +
        "<div id='motionBanner'>\u26A0 Motion Detected!</div>" +

        (hasPassword ?
        "<div id='loginOverlay'><div id='loginBox'>" +
        "<h2 style='color:var(--accent);margin-bottom:16px;text-align:center;'>\uD83D\uDD12 CAMSTREAMER</h2>" +
        "<input type='password' id='pwInput' placeholder='Password' onkeydown='if(event.key===\"Enter\")doLogin()' style='margin-bottom:10px;'/>" +
        "<button class='btn on' onclick='doLogin()' style='width:100%;padding:10px;'>Unlock</button>" +
        "<div id='loginErr' style='color:var(--red);text-align:center;margin-top:8px;font-size:.77rem;'></div>" +
        "</div></div>" : "") +

        "<div class='layout'><div class='sidebar'>" +
        "<h1>CamStreamer</h1>" +
        "<button id='btnStream' class='stream-btn' onclick='toggleStream()'>START VIDEO STREAM</button>" +
        "<div class='stat-row'>" +
        "<div class='stat'><div class='slabel'>STATUS</div><div class='sval green' id='statStatus'>Online</div></div>" +
        "<div class='stat'><div class='slabel'>BATTERY</div><div class='sval green' id='statBatt'>-</div></div>" +
        "<div class='stat'><div class='slabel'>TEMP</div><div class='sval green' id='statTemp'>-</div></div>" +
        "</div>" +

        "<div class='card'><h3>Camera</h3>" +
        "<div class='row'><button class='btn' id='btnBack' onclick='setCamera(\"back\")'>Back</button>" +
        "<button class='btn' id='btnFront' onclick='setCamera(\"front\")'>Front</button></div>" +
        "<label>Zoom <span style='color:var(--accent);float:right;' id='zoomVal'>1.0x</span></label>" +
        "<input type='range' id='zoomSlider' min='10' max='50' value='10' oninput='setZoom(this.value)'/>" +
        "<button class='btn' onclick='api(\"/focus\")' style='width:100%;'>Auto Focus</button>" +
        "</div>" +

        "<div class='card'><h3>Quality &amp; FPS</h3>" +
        "<label>Resolution</label>" +
        "<select id='qualSel' onchange='cfg(\"quality\",this.value)'>" +
        "<option value='0'>480p</option><option value='1' selected>720p</option><option value='2'>1080p</option></select>" +
        "<label>Frame Rate</label>" +
        "<select id='fpsSel' onchange='cfg(\"fps\",this.value)'>" +
        "<option value='5'>5 FPS</option><option value='10'>10 FPS</option>" +
        "<option value='15' selected>15 FPS</option><option value='30'>30 FPS</option></select>" +
        "</div>" +

        "<div class='card'><h3>Flash &amp; Modes</h3>" +
        "<label>Flash</label>" +
        "<select id='flashSel' onchange='cfg(\"flash\",this.value)'>" +
        "<option value='0'>Off</option><option value='1'>Torch</option><option value='2'>Auto</option></select>" +
        "<div class='row'>" +
        "<button class='btn' id='btnNight' onclick='toggleNight()'>Night</button>" +
        "<button class='btn rec' id='btnRec' onclick='toggleRecord()'>Record</button>" +
        "</div></div>" +

        "<div class='card'><h3>Motion</h3>" +
        "<label>Sensitivity <span style='color:var(--accent);float:right;' id='sensVal'>4</span></label>" +
        "<input type='range' id='sensSlider' min='1' max='10' value='4' oninput='setSens(this.value)'/>" +
        "<div class='row'>" +
        "<button class='btn' id='btnNotif' onclick='toggleNotif()'>Alerts: OFF</button>" +
        "<button class='btn' id='btnPermNotif' onclick='reqNotifPerm()' style='font-size:.63rem;'>Allow Notif</button>" +
        "</div></div>" +

        "<div class='card'><h3>DVR \u2014 Continuous Recording</h3>" +
        "<div style='font-size:.65rem;color:var(--muted);margin-bottom:8px;'>" +
        dvrMins + "-min clips \u00B7 keeps last " + dvrKeep + " min</div>" +
        "<div class='row'>" +
        "<button class='btn' id='btnDvr' onclick='toggleDvr()'>\u25CF Start DVR</button>" +
        "<button class='btn' onclick='loadDvrFiles()' style='flex:.55;font-size:.64rem;'>Refresh</button>" +
        "</div>" +
        "<div id='dvrFiles' style='max-height:150px;overflow-y:auto;'>" +
        "<div style='font-size:.65rem;color:var(--muted);text-align:center;padding:8px;'>No clips loaded</div>" +
        "</div></div>" +

        "<div class='card'><h3>Two-Way Audio</h3>" +
        "<button class='talk-btn' id='btnTalk' onmousedown='startTalk()' onmouseup='stopTalk()'" +
        " ontouchstart='startTalk();return false;' ontouchend='stopTalk();return false;'" +
        " ontouchcancel='stopTalk();'>\uD83C\uDF99 Hold to Talk</button>" +
        "<div id='micNote' style='margin-top:7px;font-size:.65rem;color:var(--muted);text-align:center;'>Requires HTTPS (port 8443)</div>" +
        "<audio id='phoneAudio' src='/audio' autoplay style='width:100%;margin-top:7px;' controls></audio>" +
        "</div>" +

        "<div class='card ep'><h3>Endpoints</h3>" +
        "<a href='/video' target='_blank'>/video</a>" +
        "<a href='/shot.jpg' target='_blank'>/shot.jpg</a>" +
        "<a href='/dvr_files' target='_blank'>/dvr_files</a>" +
        "</div></div>" +

        "<div class='main'><div class='stream-wrap'>" +
        "<div id='ph' class='ph'>Video stream inactive.<br>Click START VIDEO STREAM.</div>" +
        "<img id='streamImg' alt=''/>" +
        "<div id='playbackWrap'>" +
        "<video id='playbackVideo' controls playsinline></video>" +
        "<div id='playbackBar'><span id='playbackName'></span>" +
        "<button id='btnClosePlayback' onclick='closePlayback()'>\u2715 Close</button>" +
        "</div></div>" +
        "</div></div></div>" +

        "<script>" +
        "var HP=" + hp + ",auth='';" +
        "var S={streaming:false,night:false,rec:false,dvr:false,notif:false,front:false,flash:0,quality:1,fps:15,zoom:1.0,sens:4};" +
        "var isHttps=location.protocol==='https:';" +
        "if(!isHttps){document.getElementById('httpsBar').style.display='block';" +
        "document.getElementById('httpsLink').href='https://'+location.hostname+':8443';" +
        "document.getElementById('micNote').innerHTML='<a href=\"https://'+location.hostname+':8443\" style=\"color:var(--accent2)\">Switch to HTTPS</a> for mic access';}" +

        "function doLogin(){var pw=document.getElementById('pwInput').value;" +
        "fetch('/login?pw='+encodeURIComponent(pw)).then(r=>r.json()).then(d=>{" +
        "if(d.ok){auth=pw;document.getElementById('loginOverlay').style.display='none';init();}" +
        "else document.getElementById('loginErr').textContent='Wrong password';" +
        "}).catch(()=>document.getElementById('loginErr').textContent='Error');}" +
        "function aurl(u){return auth?u+(u.includes('?')?'&':'?')+'auth='+encodeURIComponent(auth):u;}" +
        "function api(u){return fetch(aurl(u)).then(r=>r.json()).catch(()=>null);}" +
        "function cfg(k,v){api('/config?'+k+'='+v);}" +

        // MJPEG reader
        "var streamCtrl=null;" +
        "function startMjpeg(){stopMjpeg();" +
        "var abort=new AbortController();streamCtrl=abort;" +
        "var img=document.getElementById('streamImg');" +
        "fetch(aurl('/video'),{signal:abort.signal}).then(function(r){" +
        "if(!r.ok||!r.body)return;" +
        "var rd=r.body.getReader(),buf=new Uint8Array(0),prev=null;" +
        "function pump(){rd.read().then(function(x){if(x.done)return;" +
        "var t=new Uint8Array(buf.length+x.value.length);t.set(buf);t.set(x.value,buf.length);buf=t;" +
        "var s=-1,e=-1;" +
        "for(var i=0;i<buf.length-1;i++){" +
        "if(buf[i]===0xFF&&buf[i+1]===0xD8&&s<0)s=i;" +
        "if(s>=0&&buf[i]===0xFF&&buf[i+1]===0xD9){e=i+2;break;}}" +
        "if(s>=0&&e>s){var bl=new Blob([buf.slice(s,e)],{type:'image/jpeg'});" +
        "var u=URL.createObjectURL(bl);img.src=u;" +
        "if(prev)URL.revokeObjectURL(prev);prev=u;buf=buf.slice(e);}" +
        "pump();}).catch(function(){});}" +
        "pump();}).catch(function(e){if(e.name!=='AbortError')console.warn(e);});}" +
        "function stopMjpeg(){if(streamCtrl){streamCtrl.abort();streamCtrl=null;}" +
        "var img=document.getElementById('streamImg');" +
        "if(img.src&&img.src.startsWith('blob:'))URL.revokeObjectURL(img.src);img.src='';}" +

        // Stream
        "function toggleStream(){api('/toggle_stream?active='+(S.streaming?0:1)).then(d=>{if(d)applyStream(!S.streaming);});}" +
        "function applyStream(on){S.streaming=on;" +
        "document.getElementById('btnStream').textContent=on?'STOP VIDEO STREAM':'START VIDEO STREAM';" +
        "document.getElementById('btnStream').classList.toggle('on',on);" +
        "document.getElementById('streamImg').style.display=on&&!document.getElementById('playbackWrap').style.display.includes('flex')?'block':'none';" +
        "document.getElementById('ph').style.display=on?'none':'block';" +
        "document.getElementById('statStatus').textContent=on?'LIVE':'Online';" +
        "if(on)startMjpeg();else stopMjpeg();}" +

        // DVR
        "function toggleDvr(){var next=!S.dvr;" +
        "api('/dvr?active='+(next?1:0)).then(function(d){if(d&&d.ok){S.dvr=next;applyDvr(next);" +
        "if(next)setTimeout(loadDvrFiles,4000);}});}" +
        "function applyDvr(on){S.dvr=on;" +
        "var btn=document.getElementById('btnDvr');" +
        "btn.textContent=on?'\u25A0 Stop DVR':'\u25CF Start DVR';" +
        "btn.classList.toggle('dvr-on',on);}" +
        "function loadDvrFiles(){api('/dvr_files').then(function(d){" +
        "var el=document.getElementById('dvrFiles');" +
        "if(!d||!d.files||!d.files.length){" +
        "el.innerHTML='<div style=\"font-size:.65rem;color:var(--muted);text-align:center;padding:8px;\">No DVR clips yet</div>';return;}" +
        "el.innerHTML='';" +
        "d.files.forEach(function(f){" +
        "var dt=new Date(f.ts);" +
        "var label=dt.toLocaleDateString()+' '+dt.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});" +
        "var size=(f.size/1048576).toFixed(1)+'MB';" +
        "var row=document.createElement('div');row.className='dvr-file';" +
        "var info=document.createElement('div');info.className='dvr-file-info';" +
        "info.innerHTML='<span class=\"dvr-file-time\">'+label+'</span><span class=\"dvr-file-size\">'+size+'</span>';" +
        "var btn=document.createElement('button');btn.className='dvr-play';" +
        "btn.textContent='\u25B6 Play';" +
        "btn.onclick=(function(name){return function(){playDvr(name);};})(f.name);" +
        "row.appendChild(info);row.appendChild(btn);el.appendChild(row);});});}" +
        "function playDvr(name){stopMjpeg();" +
        "document.getElementById('streamImg').style.display='none';" +
        "document.getElementById('ph').style.display='none';" +
        "var pw=document.getElementById('playbackWrap');" +
        "pw.style.display='flex';" +
        "document.getElementById('playbackName').textContent=name;" +
        "var vid=document.getElementById('playbackVideo');" +
        "vid.src=aurl('/playback?file='+encodeURIComponent(name));vid.play();}" +
        "function closePlayback(){var vid=document.getElementById('playbackVideo');" +
        "vid.pause();vid.src='';" +
        "document.getElementById('playbackWrap').style.display='none';" +
        "if(S.streaming){document.getElementById('streamImg').style.display='block';startMjpeg();}" +
        "else document.getElementById('ph').style.display='block';}" +

        // Controls
        "function setCamera(f){S.front=f==='front';api('/camera?facing='+f);" +
        "document.getElementById('btnBack').classList.toggle('on',!S.front);" +
        "document.getElementById('btnFront').classList.toggle('on',S.front);}" +
        "function setZoom(v){S.zoom=parseFloat((v/10).toFixed(1));" +
        "document.getElementById('zoomVal').textContent=S.zoom+'x';api('/zoom?level='+S.zoom);}" +
        "function setSens(v){S.sens=parseInt(v);document.getElementById('sensVal').textContent=v;cfg('sensitivity',v);}" +
        "function toggleNight(){S.night=!S.night;document.getElementById('btnNight').classList.toggle('on',S.night);cfg('night',S.night?1:0);}" +
        "function toggleRecord(){S.rec=!S.rec;document.getElementById('btnRec').classList.toggle('on',S.rec);cfg('record',S.rec?1:0);}" +
        "function toggleNotif(){S.notif=!S.notif;" +
        "document.getElementById('btnNotif').textContent='Alerts: '+(S.notif?'ON':'OFF');" +
        "document.getElementById('btnNotif').classList.toggle('on',S.notif);cfg('motion_notif',S.notif?1:0);}" +

        // Motion alert
        "var motionCooldown=false;" +
        "function onMotionEvent(){if(!S.notif||motionCooldown)return;" +
        "motionCooldown=true;setTimeout(function(){motionCooldown=false;},5000);" +
        "var b=document.getElementById('motionBanner');" +
        "b.style.display='block';setTimeout(function(){b.style.display='none';},4000);" +
        "try{var ac=new(window.AudioContext||window.webkitAudioContext)(),osc=ac.createOscillator(),g=ac.createGain();" +
        "osc.connect(g);g.connect(ac.destination);osc.frequency.value=880;" +
        "g.gain.setValueAtTime(0.4,ac.currentTime);g.gain.exponentialRampToValueAtTime(0.001,ac.currentTime+0.4);" +
        "osc.start();osc.stop(ac.currentTime+0.4);}catch(e){}" +
        "if(Notification&&Notification.permission==='granted')" +
        "new Notification('CamStreamer',{body:'Motion detected!',icon:aurl('/shot.jpg')});}" +
        "function reqNotifPerm(){if(!('Notification' in window)){alert('Notifications not supported');return;}" +
        "Notification.requestPermission().then(function(p){var btn=document.getElementById('btnPermNotif');" +
        "if(p==='granted'){btn.textContent='Notif: ON';btn.classList.add('on');}else btn.textContent='Notif: Denied';});}" +

        // SSE
        "var sseSource=null;" +
        "function startSse(){if(sseSource)return;sseSource=new EventSource(aurl('/motion_events'));" +
        "sseSource.addEventListener('motion',function(){onMotionEvent();});" +
        "sseSource.onerror=function(){sseSource.close();sseSource=null;setTimeout(startSse,5000);};}" +

        // applyState
        "function applyState(d){if(!d)return;" +
        "if(S.streaming!==d.streaming)applyStream(d.streaming);" +
        "if(S.rec!==d.recording){S.rec=d.recording;document.getElementById('btnRec').classList.toggle('on',S.rec);}" +
        "if(d.dvr!==undefined&&S.dvr!==d.dvr)applyDvr(d.dvr);" +
        "if(S.front!==d.front){S.front=d.front;" +
        "document.getElementById('btnBack').classList.toggle('on',!S.front);" +
        "document.getElementById('btnFront').classList.toggle('on',S.front);}" +
        "if(S.flash!==d.flash){S.flash=d.flash;document.getElementById('flashSel').value=String(d.flash);}" +
        "if(S.quality!==d.quality){S.quality=d.quality;document.getElementById('qualSel').value=String(d.quality);}" +
        "if(S.fps!==d.fps){S.fps=d.fps;document.getElementById('fpsSel').value=String(d.fps);}" +
        "if(Math.abs(S.zoom-d.zoom)>0.05){S.zoom=d.zoom;" +
        "document.getElementById('zoomSlider').value=Math.round((d.zoom-1.0)*10);" +
        "document.getElementById('zoomVal').textContent=d.zoom.toFixed(1)+'x';}" +
        "if(S.night!==d.night){S.night=d.night;document.getElementById('btnNight').classList.toggle('on',S.night);}" +
        "if(S.sens!==d.sensitivity){S.sens=d.sensitivity;" +
        "document.getElementById('sensSlider').value=d.sensitivity;" +
        "document.getElementById('sensVal').textContent=d.sensitivity;}}" +

        // Talk
        "var tWs=null,tStream=null,tCtx=null,tSrc=null,tProc=null;" +
        "var wsBase=(isHttps?'wss://':'ws://')+location.hostname+(isHttps?':8444':':8081');" +
        "function talkBtn(on){var b=document.getElementById('btnTalk');" +
        "b.classList.toggle('on',on);b.textContent=on?'\uD83D\uDD34 Talking\u2026':'\uD83C\uDF99 Hold to Talk';}" +
        "function startTalk(){if(tWs&&tWs.readyState===1)return;" +
        "if(!isHttps){alert('Microphone requires HTTPS.\\nOpen: https://'+location.hostname+':8443');return;}" +
        "if(!navigator.mediaDevices){alert('getUserMedia not available');return;}" +
        "tWs=new WebSocket(wsBase);tWs.binaryType='arraybuffer';" +
        "tWs.onopen=function(){navigator.mediaDevices.getUserMedia({audio:{sampleRate:16000,channelCount:1,echoCancellation:true,noiseSuppression:true}})" +
        ".then(function(s){tStream=s;tCtx=new(window.AudioContext||window.webkitAudioContext)({sampleRate:16000});" +
        "tSrc=tCtx.createMediaStreamSource(s);tProc=tCtx.createScriptProcessor(2048,1,1);" +
        "tProc.onaudioprocess=function(e){if(!tWs||tWs.readyState!==1)return;" +
        "var f=e.inputBuffer.getChannelData(0);var p=new Int16Array(f.length);" +
        "for(var i=0;i<f.length;i++){var v=Math.max(-1,Math.min(1,f[i]));p[i]=v<0?v*32768:v*32767;}" +
        "try{tWs.send(p.buffer);}catch(ex){}};tSrc.connect(tProc);tProc.connect(tCtx.destination);talkBtn(true);})" +
        ".catch(function(e){alert('Mic denied: '+e.message);if(tWs)tWs.close();});};" +
        "tWs.onclose=function(){talkBtn(false);tWs=null;};tWs.onerror=function(){talkBtn(false);if(tWs)tWs.close();};}" +
        "function stopTalk(){try{if(tProc)tProc.disconnect();}catch(e){}" +
        "try{if(tSrc)tSrc.disconnect();}catch(e){}try{if(tCtx)tCtx.close();}catch(e){}" +
        "if(tStream)tStream.getTracks().forEach(function(t){t.stop();});" +
        "if(tWs){try{tWs.close();}catch(e){}}tWs=null;tStream=null;tCtx=null;tSrc=null;tProc=null;talkBtn(false);}" +

        // Poll — textContent does NOT parse HTML entities, use actual Unicode chars
        "function poll(){api('/state').then(applyState);" +
        "api('/device_stats').then(function(d){if(!d)return;" +
        "var b=d.battery,t=d.temperature,c=d.charging;" +
        "var bEl=document.getElementById('statBatt'),tEl=document.getElementById('statTemp');" +
        "bEl.textContent=b>=0?b.toFixed(0)+'%'+(c?'\u26A1':''):'-';" +
        "bEl.className='sval '+(b<20?'red-c':b<50?'orange':'green');" +
        "tEl.textContent=t>=0?t.toFixed(1)+'\u00B0C':'-';" +
        "tEl.className='sval '+(t>45?'red-c':t>38?'orange':'green');});}" +

        // init
        "function init(){api('/state').then(applyState);poll();setInterval(poll,3000);" +
        "setInterval(function(){if(S.dvr)loadDvrFiles();},30000);" +
        "startSse();" +
        "if(Notification&&Notification.permission==='granted'){" +
        "var btn=document.getElementById('btnPermNotif');" +
        "if(btn){btn.textContent='Notif: ON';btn.classList.add('on');}}}" +
        "if(!HP)init();" +
        "</script></body></html>";
    }
}
