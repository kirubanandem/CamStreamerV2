package com.camstreamer.app;

import android.content.Context;
import android.graphics.*;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import java.io.*;
import java.net.*;

public class MjpegView extends View {

    private static final String TAG       = "MjpegView";
    private static final int    FRAME_MAX = 1024 * 1024;

    private String           streamUrl;
    private String           password;
    private volatile boolean running      = false;
    private volatile Bitmap  latestBitmap = null;
    private Thread           streamThread = null;
    private volatile String  statusMsg    = "idle";

    private final Paint paint, bgPaint, textPaint, subPaint;

    public MjpegView(Context ctx)                     { this(ctx, null); }
    public MjpegView(Context ctx, AttributeSet attrs) {
        super(ctx, attrs);
        paint     = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
        bgPaint   = new Paint();
        bgPaint.setColor(0xFF000000);
        textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(0xFF5a5a7a);
        textPaint.setTextSize(32f);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTypeface(Typeface.MONOSPACE);
        subPaint  = new Paint(textPaint);
        subPaint.setTextSize(22f);
    }

    public void setStreamUrl(String url) { this.streamUrl = url; }
    public void setPassword(String pw)   { this.password  = pw;  }
    public String getStreamUrl()         { return streamUrl; }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    public void startStream() {
        // Always do a clean stop first — kills any existing thread and resets running=false
        stopStream();

        if (streamUrl == null || streamUrl.isEmpty()) {
            setStatus("no URL configured"); return;
        }
        running = true;
        setStatus("connecting…");
        streamThread = new Thread(this::loop, "MjpegView");
        streamThread.setDaemon(true);
        streamThread.start();
    }

    public void stopStream() {
        running = false;
        Thread t = streamThread;
        streamThread = null;
        if (t != null) {
            t.interrupt();
            // Don't join — we never block the UI thread.
            // The thread will exit its loop on next iteration check of `running`.
        }
        Bitmap b = latestBitmap;
        latestBitmap = null;
        if (b != null && !b.isRecycled()) b.recycle();
        postInvalidate();
    }

    // ── Main streaming loop ───────────────────────────────────────────────────

    private void loop() {
        while (running) {
            HttpURLConnection conn = null;
            try {
                String url = streamUrl;
                if (password != null && !password.isEmpty())
                    url += (url.contains("?") ? "&" : "?")
                        + "auth=" + URLEncoder.encode(password, "UTF-8");

                conn = (HttpURLConnection) new URL(url).openConnection();
                conn.setConnectTimeout(8000);
                conn.setReadTimeout(20000);
                conn.setRequestProperty("Connection", "keep-alive");
                conn.setRequestProperty("Cache-Control", "no-cache");

                int code = conn.getResponseCode();
                if (code == 401) { setStatus("wrong password (401)"); sleep(5000); continue; }
                if (code != 200) { setStatus("HTTP error: " + code);  sleep(3000); continue; }

                String ct = conn.getContentType();
                if (ct != null && ct.contains("image/jpeg")) {
                    setStatus("stream not active on server");
                    conn.disconnect(); sleep(3000); continue;
                }

                setStatus("connected — waiting for frames…");

                DataInputStream in = new DataInputStream(
                    new BufferedInputStream(conn.getInputStream(), 65536));

                while (running) {
                    int contentLength = -1;
                    String line;
                    int headerLines = 0;
                    while ((line = readLine(in)) != null) {
                        headerLines++;
                        if (headerLines > 20) break;
                        String lower = line.toLowerCase().trim();
                        if (lower.startsWith("content-length:")) {
                            try {
                                contentLength = Integer.parseInt(
                                    lower.substring("content-length:".length()).trim());
                            } catch (NumberFormatException ignored) {}
                        }
                        if (line.trim().isEmpty() && headerLines > 1) break;
                    }

                    if (!running) break;

                    if (contentLength > 0 && contentLength <= FRAME_MAX) {
                        byte[] frame = new byte[contentLength];
                        in.readFully(frame);
                        decodeAndShow(frame, contentLength);
                        in.mark(4);
                        int a = in.read(), b2 = in.read();
                        if (a != '\r' || b2 != '\n') in.reset();
                    } else {
                        byte[] buf = new byte[FRAME_MAX];
                        int len = 0;
                        boolean inJpeg = false, done = false;
                        int prevByte = -1;
                        while (running && !done) {
                            int b = in.read();
                            if (b < 0) break;
                            if (!inJpeg) {
                                if (prevByte == 0xFF && b == 0xD8) {
                                    inJpeg = true;
                                    buf[len++] = (byte) 0xFF;
                                    buf[len++] = (byte) 0xD8;
                                }
                            } else {
                                if (len < FRAME_MAX) buf[len++] = (byte) b;
                                if (prevByte == 0xFF && b == 0xD9) {
                                    decodeAndShow(buf, len);
                                    done = true;
                                }
                            }
                            prevByte = b;
                        }
                    }
                }

                setStatus("stream ended — reconnecting…");

            } catch (InterruptedIOException e) {
                break;
            } catch (EOFException e) {
                if (running) { setStatus("reconnecting…"); sleep(1000); }
            } catch (Exception e) {
                if (running) {
                    String msg = e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName();
                    Log.w(TAG, "Stream error: " + msg, e);
                    setStatus("reconnecting… (" + shorten(msg) + ")");
                    sleep(2000);
                }
            } finally {
                if (conn != null) try { conn.disconnect(); } catch (Exception ignored) {}
            }
        }
    }

    private String readLine(InputStream in) throws IOException {
        StringBuilder sb = new StringBuilder(64);
        int c;
        while ((c = in.read()) != -1) {
            if (c == '\r') {
                int next = in.read();
                if (next == '\n') break;
                sb.append((char) c);
                if (next != -1) sb.append((char) next);
            } else if (c == '\n') {
                break;
            } else {
                sb.append((char) c);
            }
        }
        return c == -1 ? null : sb.toString();
    }

    private void decodeAndShow(byte[] data, int len) {
        if (len < 4) return;
        if ((data[0] & 0xFF) != 0xFF || (data[1] & 0xFF) != 0xD8) {
            Log.w(TAG, "Skipping non-JPEG frame (" + len + " bytes)");
            return;
        }
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inPreferredConfig = Bitmap.Config.RGB_565;
        opts.inMutable         = false;
        Bitmap bmp = BitmapFactory.decodeByteArray(data, 0, len, opts);
        if (bmp != null) {
            Bitmap old = latestBitmap;
            latestBitmap = bmp;
            statusMsg = "";
            postInvalidate();
            if (old != null && !old.isRecycled()) old.recycle();
        }
    }

    private void setStatus(String msg) { statusMsg = msg; postInvalidate(); }

    private void sleep(long ms) {
        try { Thread.sleep(ms); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }

    private String shorten(String s) {
        return s != null && s.length() > 40 ? s.substring(0, 40) + "…" : s;
    }

    // ── Drawing ───────────────────────────────────────────────────────────────

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth(), h = getHeight();
        if (w == 0 || h == 0) return;
        canvas.drawRect(0, 0, w, h, bgPaint);
        Bitmap bmp = latestBitmap;
        if (bmp != null && !bmp.isRecycled()) {
            float bw = bmp.getWidth(), bh = bmp.getHeight();
            float scale = Math.min(w / bw, h / bh);
            float dx = (w - bw * scale) / 2f;
            float dy = (h - bh * scale) / 2f;
            Matrix m = new Matrix();
            m.setScale(scale, scale);
            m.postTranslate(dx, dy);
            canvas.drawBitmap(bmp, m, paint);
        } else {
            String msg = statusMsg;
            if (msg != null && !msg.isEmpty())
                canvas.drawText(msg, w / 2f, h / 2f, textPaint);
            if (streamUrl != null && !streamUrl.isEmpty()) {
                String disp = streamUrl.length() > 38
                    ? streamUrl.substring(0, 38) + "…" : streamUrl;
                canvas.drawText(disp, w / 2f, h / 2f + 48f, subPaint);
            }
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        stopStream();
        super.onDetachedFromWindow();
    }
}
