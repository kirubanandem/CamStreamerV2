package com.camstreamer.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.*;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

public class GridViewActivity extends AppCompatActivity {

    private ProfileManager    profileManager;
    private Profile           profile;
    private RecyclerView      rvGrid;
    private CameraGridAdapter adapter;
    private TextView          tvProfileTitle, tvNoCameras;

    private final Handler         motionHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor      = Executors.newCachedThreadPool();
    private final Map<String, Boolean> motionState = new ConcurrentHashMap<>();

    private boolean dialogOpen = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_grid_view);

        profileManager = new ProfileManager(this);
        String pid = getIntent().getStringExtra("profile_id");
        if (pid == null) { finish(); return; }

        profile = findProfile(pid);
        if (profile == null) { finish(); return; }

        tvProfileTitle = findViewById(R.id.tvProfileTitle);
        tvNoCameras    = findViewById(R.id.tvNoCameras);
        rvGrid         = findViewById(R.id.rvGrid);

        tvProfileTitle.setText(profile.icon + "  " + profile.name);

        updateGridColumns();

        adapter = new CameraGridAdapter(
                new ArrayList<>(profile.cameras),
                this::onStreamTap,
                this::onCameraEdit,
                this::onCameraDelete
        );
        rvGrid.setAdapter(adapter);

        findViewById(R.id.btnAddCamera).setOnClickListener(v -> showCameraDialog(null));
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        refreshEmptyState();
        startMotionPolling();
    }

    @Override
    protected void onResume() {
        super.onResume();
        dialogOpen = false;
        Profile fresh = findProfile(profile.id);
        if (fresh != null) {
            boolean changed = !profilesEqual(profile.cameras, fresh.cameras);
            profile = fresh;
            if (changed) {
                adapter.updateList(new ArrayList<>(profile.cameras));
                updateGridColumns();
            }
            refreshEmptyState();
        }
    }

    private boolean profilesEqual(List<CamEntry> a, List<CamEntry> b) {
        if (a.size() != b.size()) return false;
        for (int i = 0; i < a.size(); i++)
            if (!a.get(i).id.equals(b.get(i).id)) return false;
        return true;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        motionHandler.removeCallbacksAndMessages(null);
        executor.shutdownNow();
    }

    private void updateGridColumns() {
        int cols = profile.cameras.size() == 1 ? 1 : 2;
        rvGrid.setLayoutManager(new GridLayoutManager(this, cols));
    }

    private Profile findProfile(String id) {
        for (Profile p : profileManager.loadAll()) if (p.id.equals(id)) return p;
        return null;
    }

    private void refreshEmptyState() {
        boolean empty = profile.cameras.isEmpty();
        tvNoCameras.setVisibility(empty ? View.VISIBLE : View.GONE);
        rvGrid.setVisibility(empty ? View.GONE : View.VISIBLE);
    }

    private void onStreamTap(CamEntry cam) {
        if (cam.controlBase == null || cam.controlBase.isEmpty()) {
            try {
                java.net.URL u = new java.net.URL(cam.streamUrl);
                cam.controlBase = u.getProtocol() + "://" + u.getHost()
                        + (u.getPort() != -1 ? ":" + u.getPort() : "");
                profileManager.saveProfile(profile);
            } catch (Exception ignored) {}
        }
        Intent i = new Intent(this, FullscreenStreamActivity.class);
        i.putExtra("stream_url",   cam.streamUrl);
        i.putExtra("control_base", cam.controlBase);
        i.putExtra("cam_label",    cam.label);
        i.putExtra("password",     cam.password);
        startActivity(i);
    }

    private void onCameraEdit(CamEntry cam) { showCameraDialog(cam); }

    private void onCameraDelete(CamEntry cam) {
        if (dialogOpen) return;
        dialogOpen = true;
        new AlertDialog.Builder(this)
                .setTitle("Remove camera?")
                .setMessage("Remove \"" + cam.label + "\" from this profile?")
                .setPositiveButton("Remove", (d, w) -> {
                    profile.cameras.removeIf(c -> c.id.equals(cam.id));
                    profileManager.saveProfile(profile);
                    adapter.updateList(new ArrayList<>(profile.cameras));
                    updateGridColumns();
                    refreshEmptyState();
                })
                .setNegativeButton("Cancel", null)
                .setOnDismissListener(d -> dialogOpen = false)
                .show();
    }

    private void showCameraDialog(CamEntry existing) {
        if (dialogOpen) return;
        dialogOpen = true;

        View v = getLayoutInflater().inflate(R.layout.dialog_add_camera, null);
        EditText etLabel      = v.findViewById(R.id.etCamLabel);
        EditText etStreamUrl  = v.findViewById(R.id.etStreamUrl);
        EditText etPassword   = v.findViewById(R.id.etStreamPassword);
        EditText etControlUrl = v.findViewById(R.id.etControlUrl);
        Switch   swMotion     = v.findViewById(R.id.swMotionAlerts);

        if (existing != null) {
            etLabel.setText(existing.label);
            etStreamUrl.setText(existing.streamUrl);
            etPassword.setText(existing.password);
            etControlUrl.setText(existing.controlBase);
            swMotion.setChecked(existing.motionAlerts);
        }

        etStreamUrl.setOnFocusChangeListener((fv, hasFocus) -> {
            if (!hasFocus && etControlUrl.getText().toString().trim().isEmpty()) {
                String stream = etStreamUrl.getText().toString().trim();
                if (!stream.isEmpty()) {
                    try {
                        java.net.URL u = new java.net.URL(stream);
                        String base = u.getProtocol() + "://" + u.getHost()
                                + (u.getPort() != -1 ? ":" + u.getPort() : "");
                        etControlUrl.setText(base);
                    } catch (Exception ignored) {}
                }
            }
        });

        new AlertDialog.Builder(this)
                .setTitle(existing == null ? "Add camera" : "Edit camera")
                .setView(v)
                .setPositiveButton("Save", (d, w) -> {
                    String label   = etLabel.getText().toString().trim();
                    String stream  = etStreamUrl.getText().toString().trim();
                    String pw      = etPassword.getText().toString().trim();
                    String control = etControlUrl.getText().toString().trim();
                    boolean motion = swMotion.isChecked();
                    if (label.isEmpty())  label = "Camera";
                    if (stream.isEmpty()) {
                        Toast.makeText(this, "Stream URL is required", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (existing != null) {
                        existing.label        = label;
                        existing.streamUrl    = stream;
                        existing.password     = pw;
                        existing.controlBase  = control;
                        existing.motionAlerts = motion;
                    } else {
                        profile.cameras.add(
                                new CamEntry(ProfileManager.newId(), label, stream, pw, control, motion));
                    }
                    profileManager.saveProfile(profile);
                    adapter.updateList(new ArrayList<>(profile.cameras));
                    updateGridColumns();
                    refreshEmptyState();
                })
                .setNegativeButton("Cancel", null)
                .setOnDismissListener(d -> dialogOpen = false)
                .show();
    }

    private void startMotionPolling() {
        Runnable poll = new Runnable() {
            @Override public void run() {
                if (isDestroyed()) return;
                for (CamEntry cam : new ArrayList<>(profile.cameras)) {
                    if (!cam.motionAlerts || cam.controlBase == null || cam.controlBase.isEmpty()) continue;
                    final String url    = cam.controlBase + "/motion" +
                            (cam.password.isEmpty() ? "" : "?auth=" + cam.password);
                    final String cid    = cam.id;
                    final String clabel = cam.label;
                    executor.submit(() -> {
                        try {
                            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                            c.setConnectTimeout(2000); c.setReadTimeout(2000);
                            if (c.getResponseCode() == 200) {
                                BufferedReader br = new BufferedReader(
                                    new InputStreamReader(c.getInputStream()));
                                StringBuilder sb = new StringBuilder(); String line;
                                while ((line = br.readLine()) != null) sb.append(line);
                                c.disconnect();
                                boolean detected = sb.toString().contains("\"motion\":true");

                                // Atomic swap — avoids read-compare-put race on ConcurrentHashMap.
                                // merge() returns the new value; we infer a change by comparing
                                // with the old value retrieved via getOrDefault before merge.
                                Boolean prev = motionState.getOrDefault(cid, null);
                                motionState.put(cid, detected);
                                boolean changed = prev == null || prev != detected;

                                if (changed) {
                                    final boolean det = detected;
                                    motionHandler.post(() -> {
                                        if (isDestroyed()) return;
                                        int idx = -1;
                                        for (int i = 0; i < profile.cameras.size(); i++)
                                            if (profile.cameras.get(i).id.equals(cid)) { idx = i; break; }
                                        if (idx >= 0) adapter.setMotion(idx, det);
                                        if (det)
                                            Toast.makeText(GridViewActivity.this,
                                                    "Motion: " + clabel, Toast.LENGTH_SHORT).show();
                                    });
                                }
                            }
                        } catch (Exception ignored) {}
                    });
                }
                motionHandler.postDelayed(this, 2500);
            }
        };
        motionHandler.postDelayed(poll, 2000);
    }
}

class CameraGridAdapter extends RecyclerView.Adapter<CameraGridAdapter.VH> {

    interface OnCam { void on(CamEntry c); }

    private List<CamEntry>             cams;
    private final OnCam                onTap, onEdit, onDelete;
    private final Map<String, Boolean> motionMap = new HashMap<>();

    CameraGridAdapter(List<CamEntry> cams, OnCam tap, OnCam edit, OnCam delete) {
        this.cams = cams; this.onTap = tap; this.onEdit = edit; this.onDelete = delete;
    }

    void updateList(List<CamEntry> newList) { this.cams = newList; notifyDataSetChanged(); }

    void setMotion(int idx, boolean on) {
        if (idx >= 0 && idx < cams.size()) {
            motionMap.put(cams.get(idx).id, on);
            notifyItemChanged(idx);
        }
    }

    @Override public long getItemId(int pos) { return cams.get(pos).id.hashCode(); }

    @Override
    public VH onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_stream_cell, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(VH h, int pos) {
        CamEntry cam = cams.get(pos);
        h.tvLabel.setText(cam.label);
        h.motionBadge.setVisibility(
                Boolean.TRUE.equals(motionMap.get(cam.id)) ? View.VISIBLE : View.INVISIBLE);

        String currentUrl = h.mjpegView.getStreamUrl();
        if (currentUrl == null || !currentUrl.equals(cam.streamUrl)) {
            h.mjpegView.setStreamUrl(cam.streamUrl);
            h.mjpegView.setPassword(cam.password);
            h.mjpegView.startStream();
        }

        h.mjpegView.setOnClickListener(v -> onTap.on(cam));
        h.tvLabel.setOnClickListener(v -> onTap.on(cam));
        h.btnEdit.setOnClickListener(v -> { v.setPressed(false); onEdit.on(cam); });
        h.btnDelete.setOnClickListener(v -> { v.setPressed(false); onDelete.on(cam); });
        h.root.setOnClickListener(v -> onTap.on(cam));
    }

    @Override public void onViewRecycled(VH h)           { h.mjpegView.stopStream(); }
    @Override public void onViewDetachedFromWindow(VH h) { h.mjpegView.stopStream(); }
    @Override public int  getItemCount()                 { return cams.size(); }

    static class VH extends RecyclerView.ViewHolder {
        View        root;
        TextView    tvLabel;
        View        motionBadge;
        MjpegView   mjpegView;
        ImageButton btnEdit, btnDelete;

        VH(View v) {
            super(v);
            root        = v;
            tvLabel     = v.findViewById(R.id.tvCamLabel);
            motionBadge = v.findViewById(R.id.motionBadge);
            mjpegView   = v.findViewById(R.id.mjpegView);
            btnEdit     = v.findViewById(R.id.btnCamEdit);
            btnDelete   = v.findViewById(R.id.btnCamDelete);
        }
    }
}