package com.camstreamer.app;

import android.Manifest;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.net.*;
import java.util.*;

public class MainActivity extends AppCompatActivity {

    private static final int PERMISSION_REQUEST = 100;
    public  static final String NOTIF_CHANNEL   = "CamMotion";

    private Button   btnToggleDashboard, btnToggleStreaming;
    private TextView tvStatus, tvUrls, tvMotionStatus, tvBattery, tvTemp;
    private Switch   swCamera, swTorch, swNight, swRecord, swDvr, swMotionAlerts;
    private Spinner  spQuality, spFps, spFlash;
    private SeekBar  sbMotionSensitivity, sbZoom;
    private TextView tvSensLabel, tvZoomLabel;
    private EditText etPassword;

    private ProfileManager    profileManager;
    private BroadcastReceiver uiUpdateReceiver;
    private boolean           receiverRegistered = false;

    /**
     * True while we are programmatically updating UI controls from a broadcast.
     * Prevents the control's own listener from firing an API call back.
     */
    private boolean suppressListeners = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_main);

        profileManager = new ProfileManager(this);
        createNotificationChannel();
        bindViews();
        setupSpinners();
        buildReceiver();       // build receiver object — don't register yet
        setupControls();       // attach listeners AFTER receiver is built
        requestAllPermissions();

        // Start service — it stays alive in background
        Intent intent = new Intent(this, StreamingService.class);
        intent.putExtra("password", profileManager.getPassword());
        ContextCompat.startForegroundService(this, intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Register receiver — must be done on main thread
        if (!receiverRegistered) {
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                registerReceiver(uiUpdateReceiver,
                    new IntentFilter(CamHttpServer.ACTION_UPDATE_UI),
                    Context.RECEIVER_NOT_EXPORTED);
            } else {
                registerReceiver(uiUpdateReceiver,
                    new IntentFilter(CamHttpServer.ACTION_UPDATE_UI));
            }
            receiverRegistered = true;
        }
        refreshUI();
        refreshStatsDisplay();
        // Pull actual camera state back into the UI controls (handles rotation/resume)
        syncControlsFromService();
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Do NOT unregister here — we want to keep receiving broadcasts even when
        // the screen is off so controls stay in sync. Unregister only on destroy.
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (receiverRegistered) {
            try { unregisterReceiver(uiUpdateReceiver); } catch (Exception ignored) {}
            receiverRegistered = false;
        }
    }

    private void bindViews() {
        btnToggleDashboard  = findViewById(R.id.btnToggleDashboard);
        btnToggleStreaming   = findViewById(R.id.btnToggleStreaming);
        tvStatus            = findViewById(R.id.tvStatus);
        tvUrls              = findViewById(R.id.tvUrls);
        tvMotionStatus      = findViewById(R.id.tvMotionStatus);
        tvBattery           = findViewById(R.id.tvBattery);
        tvTemp              = findViewById(R.id.tvTemp);
        swCamera            = findViewById(R.id.swCamera);
        swTorch             = findViewById(R.id.swTorch);
        swNight             = findViewById(R.id.swNight);
        swRecord            = findViewById(R.id.swRecord);
        swDvr               = findViewById(R.id.swDvr);
        swMotionAlerts      = findViewById(R.id.swMotionAlerts);
        spQuality           = findViewById(R.id.spQuality);
        spFps               = findViewById(R.id.spFps);
        spFlash             = findViewById(R.id.spFlash);
        sbMotionSensitivity = findViewById(R.id.sbMotionSensitivity);
        sbZoom              = findViewById(R.id.sbZoom);
        tvSensLabel         = findViewById(R.id.tvSensLabel);
        tvZoomLabel         = findViewById(R.id.tvZoomLabel);
        etPassword          = findViewById(R.id.etPassword);

        etPassword.setText(profileManager.getPassword());
        swMotionAlerts.setChecked(false);
    }

    private void setupSpinners() {
        ArrayAdapter<String> qAdp = new ArrayAdapter<>(this,
            android.R.layout.simple_spinner_item, new String[]{"480p","720p","1080p"});
        qAdp.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spQuality.setAdapter(qAdp);
        spQuality.setSelection(1);

        ArrayAdapter<String> fAdp = new ArrayAdapter<>(this,
            android.R.layout.simple_spinner_item, new String[]{"5 FPS","10 FPS","15 FPS","30 FPS"});
        fAdp.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spFps.setAdapter(fAdp);
        spFps.setSelection(2);

        ArrayAdapter<String> flAdp = new ArrayAdapter<>(this,
            android.R.layout.simple_spinner_item, new String[]{"Flash Off","Torch On","Auto Flash"});
        flAdp.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spFlash.setAdapter(flAdp);
    }

    private void setupControls() {
        btnToggleDashboard.setOnClickListener(v -> {
            if (StreamingService.instance != null) {
                boolean start = !StreamingService.instance.isDashboardRunning();
                if (start) profileManager.setPassword(etPassword.getText().toString().trim());
                StreamingService.instance.toggleDashboard(start);
                refreshUI();
            }
        });

        btnToggleStreaming.setOnClickListener(v -> {
            if (StreamingService.instance != null) {
                boolean start = !StreamingService.instance.isStreamingActive();
                StreamingService.instance.toggleStreaming(start);
                // Notify dashboard via broadcast so its button updates
                if (StreamingService.instance.httpServer != null)
                    StreamingService.instance.httpServer.notifyUi("streaming", start ? "1" : "0");
                refreshUI();
            }
        });

        swCamera.setOnCheckedChangeListener((b, on) -> {
            if (suppressListeners) return;
            if (svc() != null && svc().cameraController != null) {
                svc().cameraController.switchCamera(on);
                notifyDash("front", on ? "1" : "0");
            }
        });

        swTorch.setOnCheckedChangeListener((b, on) -> {
            if (suppressListeners) return;
            if (svc() != null && svc().cameraController != null) {
                int mode = on ? CameraController.FLASH_TORCH : CameraController.FLASH_OFF;
                svc().cameraController.setFlashMode(mode);
                notifyDash("flash", String.valueOf(mode));
            }
        });

        swNight.setOnCheckedChangeListener((b, on) -> {
            if (suppressListeners) return;
            if (svc() != null && svc().cameraController != null) {
                svc().cameraController.setNightMode(on);
                notifyDash("night", on ? "1" : "0");
            }
        });

        swRecord.setOnCheckedChangeListener((b, on) -> {
            if (suppressListeners) return;
            if (svc() != null) {
                svc().setRecording(on);
                notifyDash("record", on ? "1" : "0");
            }
        });

        if (swDvr != null) {
            swDvr.setOnCheckedChangeListener((b, on) -> {
                if (suppressListeners) return;
                if (svc() != null) {
                    svc().setDvr(on);
                    notifyDash("dvr", on ? "1" : "0");
                }
            });
        }

        spQuality.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, android.view.View v, int pos, long id) {
                if (suppressListeners) return;
                if (svc() != null && svc().cameraController != null) {
                    svc().cameraController.setQuality(pos);
                    notifyDash("quality", String.valueOf(pos));
                }
            }
            @Override public void onNothingSelected(AdapterView<?> p) {}
        });

        spFps.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            int[] vals = {5, 10, 15, 30};
            @Override public void onItemSelected(AdapterView<?> p, android.view.View v, int pos, long id) {
                if (suppressListeners) return;
                if (svc() != null && svc().cameraController != null) {
                    svc().cameraController.setFps(vals[pos]);
                    notifyDash("fps", String.valueOf(vals[pos]));
                }
            }
            @Override public void onNothingSelected(AdapterView<?> p) {}
        });

        spFlash.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, android.view.View v, int pos, long id) {
                if (suppressListeners) return;
                if (svc() != null && svc().cameraController != null) {
                    svc().cameraController.setFlashMode(pos);
                    notifyDash("flash", String.valueOf(pos));
                }
            }
            @Override public void onNothingSelected(AdapterView<?> p) {}
        });

        sbMotionSensitivity.setMax(9);
        sbMotionSensitivity.setProgress(3);
        tvSensLabel.setText("Sensitivity: 4");
        sbMotionSensitivity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int v, boolean u) {
                tvSensLabel.setText("Sensitivity: " + (v + 1));
                if (suppressListeners) return;
                if (svc() != null && svc().motionDetector != null) {
                    svc().motionDetector.setSensitivity(v + 1);
                    notifyDash("sensitivity", String.valueOf(v + 1));
                }
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });

        sbZoom.setMax(40);
        tvZoomLabel.setText("Zoom: 1.0x");
        sbZoom.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int v, boolean u) {
                float z = 1.0f + v * 0.1f;
                tvZoomLabel.setText(String.format("Zoom: %.1fx", z));
                if (suppressListeners) return;
                if (svc() != null && svc().cameraController != null) {
                    svc().cameraController.setZoom(z);
                    notifyDash("zoom", String.valueOf(z));
                }
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });

        etPassword.setOnFocusChangeListener((v, focus) -> {
            if (!focus) profileManager.setPassword(etPassword.getText().toString().trim());
        });

        // Motion status + battery/temp polling every 2s.
        // NOTE: motion notifications are sent to the web dashboard and viewer app
        // via the SSE /motion_events endpoint (see CamHttpServer + WebDashboard).
        // The server device itself does NOT pop a system notification — the camera
        // phone is the surveillance device, not the observer.
        tvMotionStatus.postDelayed(new Runnable() {
            @Override public void run() {
                if (svc() != null && svc().motionDetector != null) {
                    boolean m = svc().motionDetector.isMotionDetected();
                    tvMotionStatus.setText(m ? "🔴 Motion detected!" : "🟢 No motion");
                    tvMotionStatus.setTextColor(m ? 0xFFFF4444 : 0xFF44CC44);
                    // swMotionAlerts now controls whether the web dashboard shows alerts.
                    // Broadcast the current preference so the dashboard can honour it.
                    // No system notification is posted on the server device.
                }
                refreshStatsDisplay();
                tvMotionStatus.postDelayed(this, 2000);
            }
        }, 2000);
    }

    // ── BroadcastReceiver: dashboard → app ────────────────────────────────────

    private void buildReceiver() {
        uiUpdateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String key = intent.getStringExtra("key");
                String val = intent.getStringExtra("val");
                if (key == null || val == null) return;

                runOnUiThread(() -> {
                    suppressListeners = true;
                    try {
                        applyKey(key, val);
                    } finally {
                        suppressListeners = false;
                    }
                });
            }
        };
    }

    /**
     * Apply a single key=val from either the broadcast receiver (dashboard→app)
     * or from syncControlsFromService() (on resume).
     * suppressListeners must be true when called to avoid feedback loops.
     */
    private void applyKey(String key, String val) {
        switch (key) {
            case "streaming":
                refreshUI();
                break;
            case "quality":
                spQuality.setSelection(Integer.parseInt(val));
                break;
            case "fps":
                int fps = Integer.parseInt(val);
                spFps.setSelection(fps==5?0 : fps==10?1 : fps==15?2 : 3);
                break;
            case "flash":
                int fl = Integer.parseInt(val);
                spFlash.setSelection(fl);
                swTorch.setChecked(fl == CameraController.FLASH_TORCH);
                break;
            case "zoom":
                float z = Float.parseFloat(val);
                sbZoom.setProgress(Math.round((z - 1.0f) * 10));
                tvZoomLabel.setText(String.format("Zoom: %.1fx", z));
                break;
            case "front":
                swCamera.setChecked("1".equals(val));
                break;
            case "night":
                swNight.setChecked("1".equals(val));
                break;
            case "record":
                swRecord.setChecked("1".equals(val));
                break;
            case "dvr":
                if (swDvr != null) swDvr.setChecked("1".equals(val));
                break;
            case "motion_notif":
                swMotionAlerts.setChecked("1".equals(val));
                break;
            case "sensitivity":
                int s = Integer.parseInt(val);
                sbMotionSensitivity.setProgress(s - 1);
                tvSensLabel.setText("Sensitivity: " + s);
                break;
        }
    }

    /**
     * Pull actual camera state from the service and apply to UI controls.
     * Called on resume so the app UI always reflects the real camera state.
     */
    private void syncControlsFromService() {
        StreamingService s = svc();
        if (s == null || s.cameraController == null) return;

        suppressListeners = true;
        try {
            CameraController cam = s.cameraController;
            MotionDetector   mot = s.motionDetector;

            applyKey("quality",     String.valueOf(cam.getQualityIndex()));
            applyKey("fps",         String.valueOf(cam.getFps()));
            applyKey("flash",       String.valueOf(cam.getFlashMode()));
            applyKey("zoom",        String.valueOf(cam.getZoomLevel()));
            applyKey("front",       cam.isFrontCamera() ? "1" : "0");
            applyKey("night",       cam.isNightMode()   ? "1" : "0");
            applyKey("record",      s.isRecording()     ? "1" : "0");
            applyKey("dvr",         s.isDvrRunning      ? "1" : "0");
            if (mot != null)
                applyKey("sensitivity", String.valueOf(mot.getSensitivity()));
        } finally {
            suppressListeners = false;
        }
    }

    // ── Stats display ─────────────────────────────────────────────────────────

    private void refreshStatsDisplay() {
        StreamingService s = svc();
        if (s == null) return;
        float batt    = s.getBatteryLevel();
        float temp    = s.getTemperature();
        boolean charg = s.isCharging();

        if (tvBattery != null) {
            tvBattery.setText(batt >= 0
                ? String.format("🔋 %.0f%% %s", batt, charg ? "⚡" : "") : "🔋 –");
            tvBattery.setTextColor(batt < 20 ? 0xFFFF4444 : batt < 50 ? 0xFFFF9944 : 0xFF44CC44);
        }
        if (tvTemp != null) {
            tvTemp.setText(temp >= 0 ? String.format("🌡 %.1f°C", temp) : "🌡 –");
            tvTemp.setTextColor(temp > 45 ? 0xFFFF4444 : temp > 38 ? 0xFFFF9944 : 0xFF44CC44);
        }
    }

    // ── UI refresh ────────────────────────────────────────────────────────────

    private void refreshUI() {
        StreamingService s = svc();
        if (s == null) return;

        boolean dash   = s.isDashboardRunning();
        boolean stream = s.isStreamingActive();

        btnToggleDashboard.setText(dash ? "Stop Dashboard" : "Start Dashboard");
        btnToggleDashboard.setBackgroundTintList(
            android.content.res.ColorStateList.valueOf(dash ? 0xFFff3b3b : 0xFF534ab7));

        btnToggleStreaming.setText(stream ? "Stop Stream" : "Start Stream");
        btnToggleStreaming.setBackgroundTintList(
            android.content.res.ColorStateList.valueOf(stream ? 0xFFff3b3b : 0xFF0f6e56));

        if (dash || stream) {
            String dvrTag = (s.isDvrRunning ? " DVR" : "");
            tvStatus.setText("🟢 Active: " + (dash ? "Web " : "") + (stream ? "Stream" : "") + dvrTag);
            tvStatus.setTextColor(0xFF00e5a0);
            String ip = getLocalIp();
            tvUrls.setText(
                "Dashboard (HTTP) : http://" + ip + ":8080\n" +
                "Dashboard (HTTPS): https://" + ip + ":8443  ← use this for mic/talk\n" +
                "Stream           : http://" + ip + ":8080/video");
        } else {
            tvStatus.setText("🔴 All Services Stopped");
            tvStatus.setTextColor(0xFF5a5a7a);
            tvUrls.setText("");
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private StreamingService svc() { return StreamingService.instance; }

    /** Notify the web dashboard of a value change initiated from the app. */
    private void notifyDash(String key, String val) {
        StreamingService s = svc();
        if (s != null && s.httpServer != null)
            s.httpServer.notifyUi(key, val);
    }

    // ── Notification channel (still needed for other system notifications) ──────

    private void createNotificationChannel() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                NOTIF_CHANNEL, "Motion Alerts", NotificationManager.IMPORTANCE_HIGH);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }

    private String getLocalIp() {
        try {
            for (NetworkInterface iface : Collections.list(NetworkInterface.getNetworkInterfaces()))
                for (InetAddress addr : Collections.list(iface.getInetAddresses()))
                    if (!addr.isLoopbackAddress() && addr.getHostAddress().contains("."))
                        return addr.getHostAddress();
        } catch (Exception e) { e.printStackTrace(); }
        return "0.0.0.0";
    }

    private void requestAllPermissions() {
        List<String> needed = new ArrayList<>(Arrays.asList(
            Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO));
        if (android.os.Build.VERSION.SDK_INT >= 33)
            needed.add(Manifest.permission.POST_NOTIFICATIONS);
        needed.removeIf(p -> ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED);
        if (!needed.isEmpty())
            ActivityCompat.requestPermissions(this, needed.toArray(new String[0]), PERMISSION_REQUEST);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
            String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != PERMISSION_REQUEST) return;

        List<String> critical  = new ArrayList<>(); // camera / mic denied
        List<String> permanent = new ArrayList<>(); // permanently denied

        for (int i = 0; i < permissions.length; i++) {
            if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                boolean perm = !ActivityCompat
                    .shouldShowRequestPermissionRationale(this, permissions[i]);
                String msg = friendlyPermName(permissions[i]);
                if (perm) permanent.add(msg); else critical.add(msg);
            }
        }

        if (critical.isEmpty() && permanent.isEmpty()) return;

        StringBuilder sb = new StringBuilder();
        if (!permanent.isEmpty()) {
            sb.append("These permissions were permanently denied "
                + "(you tapped 'Don't ask again'):\n\n");
            for (String p : permanent) sb.append("• ").append(p).append("\n");
            sb.append("\nFix: Settings → Apps → CamStreamer → Permissions\n\n");
        }
        if (!critical.isEmpty()) {
            sb.append("These permissions were denied:\n\n");
            for (String c : critical) sb.append("• ").append(c).append("\n");
            sb.append("\nServer mode requires Camera and Microphone to work.");
        }

        new android.app.AlertDialog.Builder(this)
            .setTitle("Permissions Required")
            .setMessage(sb.toString().trim())
            .setPositiveButton(permanent.isEmpty() ? "Try Again" : "Open Settings", (d, w) -> {
                if (!permanent.isEmpty()) {
                    Intent intent = new Intent(
                        android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    intent.setData(android.net.Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                } else {
                    requestAllPermissions();
                }
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private String friendlyPermName(String p) {
        switch (p) {
            case Manifest.permission.CAMERA:       return "Camera — required for video streaming";
            case Manifest.permission.RECORD_AUDIO: return "Microphone — required for audio";
            case Manifest.permission.POST_NOTIFICATIONS: return "Notifications — for motion alerts";
            default: return p.replace("android.permission.", "");
        }
    }
}
