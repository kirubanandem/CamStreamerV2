package com.camstreamer.app;

import android.view.*;
import android.widget.*;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

class ProfileAdapter extends RecyclerView.Adapter<ProfileAdapter.VH> {

    interface OnClick { void on(Profile p); }

    private final List<Profile> data;
    private final OnClick       onOpen, onEdit, onDelete;

    ProfileAdapter(List<Profile> data, OnClick open, OnClick edit, OnClick delete) {
        this.data     = data;
        this.onOpen   = open;
        this.onEdit   = edit;
        this.onDelete = delete;
    }

    @Override
    public VH onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.item_profile, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(VH h, int pos) {
        Profile p = data.get(pos);
        h.tvIcon.setText(p.icon);
        h.tvName.setText(p.name);
        h.tvCount.setText(p.cameras.size() + " camera" + (p.cameras.size() == 1 ? "" : "s"));

        h.root.setOnClickListener(v -> onOpen.on(p));
        h.btnEdit.setOnClickListener(v -> onEdit.on(p));
        h.btnDel.setOnClickListener(v -> onDelete.on(p));
    }

    @Override public int getItemCount() { return data.size(); }

    static class VH extends RecyclerView.ViewHolder {
        View        root;
        TextView    tvIcon, tvName, tvCount;
        ImageButton btnEdit, btnDel;

        VH(View v) {
            super(v);
            root    = v;
            tvIcon  = v.findViewById(R.id.tvProfileIcon);
            tvName  = v.findViewById(R.id.tvProfileName);
            tvCount = v.findViewById(R.id.tvCameraCount);
            btnEdit = v.findViewById(R.id.btnEditProfile);
            btnDel  = v.findViewById(R.id.btnDeleteProfile);
        }
    }
}
