package com.camstreamer.app;

import android.content.Context;
import android.util.Log;

import java.io.*;
import java.math.BigInteger;
import java.security.*;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import javax.net.ssl.*;

/**
 * Generates (or reuses) a self-signed TLS certificate for NanoHTTPD's HTTPS
 * server and NanoWSD's WSS server.
 *
 * WHY THIS FILE WAS REWRITTEN
 * ───────────────────────────
 * The previous version had three fatal bugs on modern Android:
 *
 * 1. KeyStore.getInstance("BKS", "BC") — the Bouncy Castle system provider
 *    ("BC") is removed in AOSP builds starting around Android 9/10.  This
 *    threw NoSuchProviderException, getFactory() returned null, and the HTTPS
 *    server silently never started.
 *
 * 2. generateFallbackCert() used sun.security.x509.* reflection.  Those
 *    classes do not exist on Android at all (they are a desktop JDK artefact).
 *    The fallback always threw ClassNotFoundException.
 *
 * 3. The BouncyCastle reflection path looked for
 *    org.bouncycastle.cert.X509v3CertificateBuilder — this class lives in the
 *    full bcpkix jar, NOT in Android's stripped system BC provider, so
 *    Class.forName() threw ClassNotFoundException there too.
 *
 * THE FIX
 * ───────
 * • KeyStore type: PKCS12.  Supported natively on all Android versions; the
 *   recommended type since API 28.  No provider argument needed.
 *
 * • Certificate generation: hand-built DER encoding using only
 *   java.security and javax.net.ssl — both always present on Android.
 *   We build the TBSCertificate byte-by-byte as a DER SEQUENCE, sign it
 *   with SHA256withRSA via java.security.Signature, wrap the result in a
 *   Certificate DER SEQUENCE, then parse it back through
 *   CertificateFactory.getInstance("X.509") which is always available.
 *
 * Users still need to click "Advanced → Proceed" once in their browser
 * because the cert is self-signed, but that is unavoidable on a LAN without
 * a public CA.  The HTTPS scheme is required so Chrome/Safari allow
 * getUserMedia() (microphone access) from a non-localhost origin.
 */
public class SslHelper {

    private static final String TAG        = "SslHelper";
    private static final String KS_FILE    = "camstreamer_ssl.p12";
    private static final char[] KS_PASS    = "camstreamer_tls".toCharArray();
    private static final String ALIAS      = "cam";
    private static final int    KEY_BITS   = 2048;
    private static final int    VALID_DAYS = 3650;   // 10 years

    private static SSLServerSocketFactory cachedFactory = null;

    // ── Public API ────────────────────────────────────────────────────────────

    /** Returns a cached or freshly-built SSLServerSocketFactory, or null on error. */
    public static synchronized SSLServerSocketFactory getFactory(Context ctx) {
        if (cachedFactory != null) return cachedFactory;
        try {
            KeyStore ks = loadOrCreate(ctx);

            KeyManagerFactory kmf =
                KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
            kmf.init(ks, KS_PASS);

            SSLContext sslCtx = SSLContext.getInstance("TLS");
            sslCtx.init(kmf.getKeyManagers(), null, new SecureRandom());

            cachedFactory = sslCtx.getServerSocketFactory();
            Log.i(TAG, "SSL factory ready (PKCS12 keystore)");
            return cachedFactory;
        } catch (Exception e) {
            Log.e(TAG, "SSL setup failed: " + e.getMessage(), e);
            return null;
        }
    }

    /** Force regeneration next time (call if the file is deleted externally). */
    public static synchronized void invalidate() {
        cachedFactory = null;
    }

    // ── KeyStore load / create ────────────────────────────────────────────────

    private static KeyStore loadOrCreate(Context ctx) throws Exception {
        File file = new File(ctx.getFilesDir(), KS_FILE);

        if (file.exists()) {
            try {
                KeyStore ks = KeyStore.getInstance("PKCS12");
                try (FileInputStream fis = new FileInputStream(file)) {
                    ks.load(fis, KS_PASS);
                }
                if (ks.containsAlias(ALIAS)) {
                    Log.i(TAG, "Loaded existing cert (" + file.getName() + ")");
                    return ks;
                }
            } catch (Exception e) {
                Log.w(TAG, "Keystore unreadable, regenerating: " + e.getMessage());
                file.delete();
            }
        }

        return createAndSave(file);
    }

    private static KeyStore createAndSave(File dest) throws Exception {
        Log.i(TAG, "Generating new self-signed TLS certificate…");

        // ── Step 1: RSA key pair ──────────────────────────────────────────────
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
        kpg.initialize(KEY_BITS, new SecureRandom());
        KeyPair kp = kpg.generateKeyPair();

        // ── Step 2: Self-signed X.509 v1 certificate ─────────────────────────
        X509Certificate cert = selfSignedCert(kp);

        // ── Step 3: PKCS12 keystore ───────────────────────────────────────────
        KeyStore ks = KeyStore.getInstance("PKCS12");
        ks.load(null, null);
        ks.setKeyEntry(ALIAS, kp.getPrivate(), KS_PASS,
            new java.security.cert.Certificate[]{cert});

        try (FileOutputStream fos = new FileOutputStream(dest)) {
            ks.store(fos, KS_PASS);
        }
        Log.i(TAG, "New cert saved to " + dest.getName());
        return ks;
    }

    // ── Self-signed X.509 v1 certificate via DER encoding ────────────────────
    //
    // We build the certificate entirely from java.security primitives.
    // No Bouncy Castle, no sun.security.*, no reflection.
    //
    // X.509 Certificate (simplified v1, which is what we need):
    //
    //   Certificate ::= SEQUENCE {
    //       tbsCertificate   TBSCertificate,
    //       signatureAlgorithm AlgorithmIdentifier,   -- SHA256withRSA
    //       signatureValue   BIT STRING
    //   }
    //
    //   TBSCertificate ::= SEQUENCE {
    //       serialNumber     INTEGER,
    //       signature        AlgorithmIdentifier,
    //       issuer           Name,
    //       validity         Validity,
    //       subject          Name,
    //       subjectPublicKeyInfo SubjectPublicKeyInfo  -- already DER from getEncoded()
    //   }
    //
    // We omit the [0] version field (defaults to v1 = 0).
    //
    // After building the DER blob we parse it through
    //   CertificateFactory.getInstance("X.509").generateCertificate()
    // which is always available and gives us a proper JCA X509Certificate.

    private static X509Certificate selfSignedCert(KeyPair kp) throws Exception {
        long nowMs     = System.currentTimeMillis();
        Date notBefore = new Date(nowMs - 60_000L);
        Date notAfter  = new Date(nowMs + (long) VALID_DAYS * 86_400_000L);
        BigInteger serial = BigInteger.valueOf(nowMs / 1000L);

        // AlgorithmIdentifier for SHA256withRSA: OID 1.2.840.113549.1.1.11, params NULL
        byte[] algId = derSeq(cat(
            derOid(new int[]{1, 2, 840, 113549, 1, 1, 11}),
            derNull()
        ));

        // DN: SEQUENCE { SET { SEQUENCE { OID(commonName), UTF8String("CamStreamer") } } }
        byte[] dn = derDN("CamStreamer");

        // SubjectPublicKeyInfo — Java already returns this in DER format
        byte[] spki = kp.getPublic().getEncoded();

        // TBSCertificate
        byte[] tbs = derSeq(cat(
            derInt(serial),
            algId,
            dn,                                    // issuer
            derSeq(cat(derUtcTime(notBefore), derUtcTime(notAfter))),  // validity
            dn,                                    // subject (same as issuer — self-signed)
            spki
        ));

        // Sign TBSCertificate
        Signature sig = Signature.getInstance("SHA256withRSA");
        sig.initSign(kp.getPrivate());
        sig.update(tbs);
        byte[] sigBytes = sig.sign();

        // Full Certificate DER
        byte[] certDer = derSeq(cat(tbs, algId, derBitString(sigBytes)));

        // Parse through CertificateFactory to get a usable JCA object
        CertificateFactory cf = CertificateFactory.getInstance("X.509");
        return (X509Certificate) cf.generateCertificate(new ByteArrayInputStream(certDer));
    }

    // ── DER / ASN.1 helpers ───────────────────────────────────────────────────

    /** DER SEQUENCE (tag 0x30) */
    private static byte[] derSeq(byte[] content) {
        return derTlv(0x30, content);
    }

    /** DER INTEGER from BigInteger */
    private static byte[] derInt(BigInteger v) {
        return derTlv(0x02, v.toByteArray());
    }

    /** DER NULL (0x05 0x00) */
    private static byte[] derNull() {
        return new byte[]{0x05, 0x00};
    }

    /**
     * DER OID encoding.
     * First two arcs are combined as 40*arc[0] + arc[1].
     * Remaining arcs are base-128 encoded, MSB first, high bit set on all but last byte.
     */
    private static byte[] derOid(int[] arcs) {
        ByteArrayOutputStream body = new ByteArrayOutputStream();
        body.write(40 * arcs[0] + arcs[1]);
        for (int i = 2; i < arcs.length; i++) {
            int v = arcs[i];
            if (v < 0x80) {
                body.write(v);
            } else {
                // Encode in base-128, big-endian
                int[] chunks = new int[6];
                int n = 0;
                while (v > 0) { chunks[n++] = v & 0x7F; v >>>= 7; }
                for (int j = n - 1; j >= 0; j--)
                    body.write(chunks[j] | (j > 0 ? 0x80 : 0x00));
            }
        }
        return derTlv(0x06, body.toByteArray());
    }

    /**
     * Minimal DER Name (RDNSequence) with a single commonName attribute.
     * commonName OID: 2.5.4.3
     */
    private static byte[] derDN(String cn) {
        byte[] cnBytes;
        try { cnBytes = cn.getBytes("UTF-8"); }
        catch (Exception e) { cnBytes = cn.getBytes(); }

        // AttributeTypeAndValue ::= SEQUENCE { type OID, value ANY }
        byte[] atv = derSeq(cat(
            derOid(new int[]{2, 5, 4, 3}),   // id-at-commonName
            derTlv(0x0C, cnBytes)             // UTF8String
        ));
        // RelativeDistinguishedName ::= SET SIZE (1..MAX) OF AttributeTypeAndValue
        byte[] rdn = derTlv(0x31, atv);      // SET (0x31)
        // RDNSequence ::= SEQUENCE OF RelativeDistinguishedName
        return derSeq(rdn);
    }

    /**
     * DER UTCTime (tag 0x17): YYMMDDHHmmssZ
     * Note: for dates after 2049 use GeneralizedTime, but our 10-year cert
     * starting now will not reach 2050 before app is long obsolete.
     */
    private static byte[] derUtcTime(Date date) {
        Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        c.setTime(date);
        String s = String.format(Locale.US, "%02d%02d%02d%02d%02d%02dZ",
            c.get(Calendar.YEAR) % 100,
            c.get(Calendar.MONTH) + 1,
            c.get(Calendar.DAY_OF_MONTH),
            c.get(Calendar.HOUR_OF_DAY),
            c.get(Calendar.MINUTE),
            c.get(Calendar.SECOND));
        try { return derTlv(0x17, s.getBytes("ASCII")); }
        catch (Exception e) { return derTlv(0x17, s.getBytes()); }
    }

    /**
     * DER BIT STRING (tag 0x03).
     * Prepends a 0x00 byte indicating zero unused bits in the last byte.
     */
    private static byte[] derBitString(byte[] data) {
        byte[] body = new byte[data.length + 1];
        body[0] = 0x00;
        System.arraycopy(data, 0, body, 1, data.length);
        return derTlv(0x03, body);
    }

    /**
     * Build a DER TLV: tag byte + length encoding + value bytes.
     * Handles lengths 0 through ~8 MB (more than enough for a certificate).
     */
    private static byte[] derTlv(int tag, byte[] value) {
        int len = value.length;
        ByteArrayOutputStream out = new ByteArrayOutputStream(4 + len);
        out.write(tag);
        if (len < 0x80) {
            out.write(len);
        } else if (len < 0x100) {
            out.write(0x81);
            out.write(len);
        } else if (len < 0x10000) {
            out.write(0x82);
            out.write(len >> 8);
            out.write(len & 0xFF);
        } else {
            out.write(0x83);
            out.write((len >> 16) & 0xFF);
            out.write((len >>  8) & 0xFF);
            out.write( len        & 0xFF);
        }
        try { out.write(value); } catch (IOException ignored) {}
        return out.toByteArray();
    }

    /** Concatenate any number of byte arrays. */
    private static byte[] cat(byte[]... parts) {
        int total = 0;
        for (byte[] p : parts) total += p.length;
        byte[] out = new byte[total];
        int pos = 0;
        for (byte[] p : parts) {
            System.arraycopy(p, 0, out, pos, p.length);
            pos += p.length;
        }
        return out;
    }
}
