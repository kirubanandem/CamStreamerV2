package com.camstreamer.app;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

/**
 * Pixel-diff motion detector.
 *
 * Fixes applied:
 *  1. Bitmap decode and scale are done OUTSIDE the synchronized block so
 *     15fps camera callbacks never block /motion HTTP reads.
 *  2. motionEventCount is now a long to avoid int overflow.
 *  3. A MotionListener callback fires on the first frame of each new motion
 *     event, so the HTTP server can push a notification to connected web
 *     clients and GridViewActivity without polling.
 */
public class MotionDetector {

    /** Callback fired (from the camera thread) on rising edge of each motion event. */
    public interface MotionListener {
        void onMotionDetected();
    }

    private volatile MotionListener listener;

    private int[]   previousPixels   = null;
    private boolean motionDetected   = false;
    private int     sensitivity      = 4;
    private long    lastMotionTime   = 0;
    private long    motionEventCount = 0;   // long: survives multi-day runs

    // sensitivity → pixel-change threshold (higher sensitivity = lower threshold)
    private double getThreshold() {
        // sensitivity 1  → 15% change needed
        // sensitivity 10 → 0.5% change needed
        return 0.155 - (sensitivity * 0.015);
    }

    private int getColorDelta() {
        // sensitivity 1  → delta 60
        // sensitivity 10 → delta 15
        return 65 - (sensitivity * 5);
    }

    public void setMotionListener(MotionListener l) { this.listener = l; }

    public void detect(byte[] jpegData) {
        // ── Bitmap work outside the lock ──────────────────────────────────────
        Bitmap bmp = BitmapFactory.decodeByteArray(jpegData, 0, jpegData.length);
        if (bmp == null) return;

        Bitmap small = Bitmap.createScaledBitmap(bmp, 160, 90, false);
        bmp.recycle();

        int w = small.getWidth(), h = small.getHeight();
        int[] pixels = new int[w * h];
        small.getPixels(pixels, 0, w, 0, 0, w, h);
        small.recycle();

        // ── State update inside the lock ──────────────────────────────────────
        boolean risingEdge;
        synchronized (this) {
            if (previousPixels == null || previousPixels.length != pixels.length) {
                previousPixels = pixels;
                return;
            }

            int changed    = 0;
            int colorDelta = getColorDelta();

            for (int i = 0; i < pixels.length; i++) {
                int dr = Math.abs(((pixels[i] >> 16) & 0xFF) - ((previousPixels[i] >> 16) & 0xFF));
                int dg = Math.abs(((pixels[i] >>  8) & 0xFF) - ((previousPixels[i] >>  8) & 0xFF));
                int db = Math.abs(( pixels[i]        & 0xFF) - ( previousPixels[i]        & 0xFF));
                if ((dr + dg + db) > colorDelta) changed++;
            }

            boolean newMotion = ((double) changed / pixels.length) > getThreshold();

            risingEdge = newMotion && !motionDetected;
            if (newMotion) {
                lastMotionTime = System.currentTimeMillis();
                if (risingEdge) motionEventCount++;
            }
            // Debounce — keep flag true for 3 s after last trigger
            motionDetected = (System.currentTimeMillis() - lastMotionTime) < 3_000;

            previousPixels = pixels;
        }

        // Fire callback outside the lock so listener can call back into detector
        if (risingEdge) {
            MotionListener l = listener;
            if (l != null) l.onMotionDetected();
        }
    }

    public synchronized void setSensitivity(int s) {
        sensitivity = Math.max(1, Math.min(10, s));
    }

    public synchronized boolean isMotionDetected() { return motionDetected; }
    public synchronized int     getSensitivity()   { return sensitivity; }
    public synchronized long    getEventCount()    { return motionEventCount; }
    public synchronized long    getLastMotionTime(){ return lastMotionTime; }
}
