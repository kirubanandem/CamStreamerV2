package com.camstreamer.app;

import android.annotation.SuppressLint;
import android.media.*;
import android.os.*;
import android.util.Log;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.io.*;
import java.net.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Locale;
import java.util.concurrent.*;

public class FullscreenStreamActivity extends AppCompatActivity {

    private static final String TAG = "FullscreenStream";

    private MjpegView mjpegView;
    private View      controlsOverlay;
    private TextView  tvMotion, tvBattery, tvTemp, tvTapHint;
    private TextView  tvZoom, tvMotionSens;
    private SeekBar   sbZoom, sbMotion, sbListenVol, sbTalkVol;
    private Spinner   spFlash, spQual, spFps;
    private Button    btnMute, btnStream, btnTalk, btnNight, btnRecord;

    private String  controlBase;
    private String  password;
    private boolean streamActive   = true;
    private boolean nightOn        = false;
    private boolean recordOn       = false;
    private boolean frontCam       = false;
    private boolean overlayVisible = false;
    private boolean controlsReady  = false;
    private boolean isMuted        = false;
    private float   talkGain       = 0.8f;

    private final ExecutorService executor  = Executors.newCachedThreadPool();
    private final Handler         uiHandler = new Handler(Looper.getMainLooper());

    private AudioTrack       listenTrack;
    private volatile boolean listenRunning = false;
    private AudioRecord      talkRecord;
    private volatile boolean talkRunning = false;
    private WebSocketClient  talkSocket;

    private AdapterView.OnItemSelectedListener flashListener, qualListener, fpsListener;
    private final Runnable autoHide = this::hideControls;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_fullscreen);

        controlBase = formatUrl(getIntent().getStringExtra("control_base"));
        password = getIntent().getStringExtra("password");
        if (password == null) password = "";

        // Auto-derive controlBase from streamUrl if not explicitly set
        String streamUrl = getIntent().getStringExtra("stream_url");
        if ((controlBase == null || controlBase.isEmpty()) && streamUrl != null) {
            try {
                java.net.URL u = new java.net.URL(streamUrl);
                controlBase = u.getProtocol() + "://" + u.getHost()
                    + (u.getPort() != -1 ? ":" + u.getPort() : "");
            } catch (Exception ignored) {}
        }

        mjpegView        = findViewById(R.id.fullMjpeg);
        controlsOverlay  = findViewById(R.id.controlsOverlay);
        TextView tvLabel = findViewById(R.id.tvFullLabel);
        tvMotion         = findViewById(R.id.tvFullMotion);
        tvBattery        = findViewById(R.id.tvFullBattery);
        tvTemp           = findViewById(R.id.tvFullTemp);
        tvTapHint        = findViewById(R.id.tvTapHint);
        sbZoom           = findViewById(R.id.sbFullZoom);
        tvZoom           = findViewById(R.id.tvFullZoom);
        sbMotion         = findViewById(R.id.sbFullMotion);
        tvMotionSens     = findViewById(R.id.tvFullMotionSens);
        sbListenVol      = findViewById(R.id.sbFullListenVol);
        sbTalkVol        = findViewById(R.id.sbFullTalkVol);
        btnMute          = findViewById(R.id.btnFullMute);
        spFlash          = findViewById(R.id.spFullFlash);
        spQual           = findViewById(R.id.spFullQual);
        spFps            = findViewById(R.id.spFullFps);
        Button btnFullBack     = findViewById(R.id.btnFullBack);
        Button btnHideControls = findViewById(R.id.btnHideControls);
        btnStream        = findViewById(R.id.btnFullStream);
        Button btnSnap   = findViewById(R.id.btnFullSnap);
        btnTalk          = findViewById(R.id.btnFullTalk);
        btnNight         = findViewById(R.id.btnFullNight);
        btnRecord        = findViewById(R.id.btnFullRecord);
        Button btnFocus  = findViewById(R.id.btnFullFocus);

        if (tvLabel != null) tvLabel.setText(getIntent().getStringExtra("cam_label"));
        mjpegView.setOnClickListener(v -> toggleControls());
        mjpegView.setStreamUrl(streamUrl);
        mjpegView.setPassword(password);
        mjpegView.startStream();

        btnFullBack.setOnClickListener(v -> finish());
        btnHideControls.setOnClickListener(v -> hideControls());
        btnStream.setOnClickListener(v -> {
            resetAutoHide();
            streamActive = !streamActive;
            camApi("/toggle_stream?active=" + (streamActive ? "1" : "0"));
            if (streamActive) mjpegView.startStream();
            else mjpegView.stopStream();
            updateStreamBtn();
        });

        btnMute.setOnClickListener(v -> {
            resetAutoHide();
            isMuted = !isMuted;
            btnMute.setText(isMuted ? "Unmute" : "Mute");
            btnMute.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                isMuted ? 0xFFff3b3b : 0xFF12121a));
            if (listenTrack != null)
                listenTrack.setVolume(isMuted ? 0 : sbListenVol.getProgress() / 100f);
        });

        sbListenVol.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean u) {
                if (listenTrack != null && !isMuted) listenTrack.setVolume(p / 100f);
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });

        sbTalkVol.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean u) { talkGain = p / 100f; }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });

        sbZoom.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean u) {
                float z = 1f + p * 0.1f;
                tvZoom.setText(String.format(Locale.US, "%.1fx", z));
                if (u && controlsReady) { resetAutoHide(); camApi("/zoom?level=" + z); }
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });

        sbMotion.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean u) {
                tvMotionSens.setText(String.valueOf(p + 1));
                if (u && controlsReady) { resetAutoHide(); camApi("/config?sensitivity=" + (p + 1)); }
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });

        ArrayAdapter<String> fa = new ArrayAdapter<>(this,
            android.R.layout.simple_spinner_item, new String[]{"Off", "Torch", "Auto"});
        fa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spFlash.setAdapter(fa);
        flashListener = new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> a, View v, int p, long id) {
                if (controlsReady) { resetAutoHide(); camApi("/flash?mode=" + (p==1?"torch":p==2?"auto":"off")); }
            }
            @Override public void onNothingSelected(AdapterView<?> a) {}
        };
        spFlash.setOnItemSelectedListener(flashListener);

        ArrayAdapter<String> qa = new ArrayAdapter<>(this,
            android.R.layout.simple_spinner_item, new String[]{"480p", "720p", "1080p"});
        qa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spQual.setAdapter(qa);
        spQual.setSelection(1);
        qualListener = new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> a, View v, int p, long id) {
                if (controlsReady) { resetAutoHide(); camApi("/config?quality=" + p); }
            }
            @Override public void onNothingSelected(AdapterView<?> a) {}
        };
        spQual.setOnItemSelectedListener(qualListener);

        ArrayAdapter<String> fpa = new ArrayAdapter<>(this,
            android.R.layout.simple_spinner_item, new String[]{"5 FPS", "10 FPS", "15 FPS", "30 FPS"});
        fpa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spFps.setAdapter(fpa);
        spFps.setSelection(2);
        fpsListener = new AdapterView.OnItemSelectedListener() {
            final int[] vals = {5, 10, 15, 30};
            @Override public void onItemSelected(AdapterView<?> a, View v, int p, long id) {
                if (controlsReady) { resetAutoHide(); camApi("/config?fps=" + vals[p]); }
            }
            @Override public void onNothingSelected(AdapterView<?> a) {}
        };
        spFps.setOnItemSelectedListener(fpsListener);

        findViewById(R.id.btnFullFront).setOnClickListener(v -> {
            resetAutoHide(); frontCam = !frontCam;
            camApi("/camera?facing=" + (frontCam ? "front" : "back")); updateFrontBtn();
        });
        btnNight.setOnClickListener(v -> {
            resetAutoHide(); nightOn = !nightOn;
            camApi("/config?night=" + (nightOn ? "1" : "0")); updateToggleBtn(btnNight, nightOn, "Night");
        });
        btnRecord.setOnClickListener(v -> {
            resetAutoHide(); recordOn = !recordOn;
            camApi("/config?record=" + (recordOn ? "1" : "0")); updateToggleBtn(btnRecord, recordOn, "Record");
        });
        btnFocus.setOnClickListener(v -> { resetAutoHide(); camApi("/focus"); });
        btnSnap.setOnClickListener(v -> { resetAutoHide(); takeSnapshot(); });
        btnTalk.setOnTouchListener((v, e) -> {
            resetAutoHide();
            if (e.getAction() == MotionEvent.ACTION_DOWN) { v.performClick(); startTalk(); }
            else if (e.getAction() == MotionEvent.ACTION_UP
                  || e.getAction() == MotionEvent.ACTION_CANCEL) stopTalk();
            return true;
        });

        controlsReady = true;
        updateStreamBtn();
        loadCurrentState();
        startMotionPolling();
        startStatsPolling();
        startListening();
    }

    // ── URL helper ────────────────────────────────────────────────────────────

    private String formatUrl(String url) {
        if (url == null || url.isEmpty()) return "";
        String f = url.trim();
        if (!f.startsWith("http")) f = "http://" + f;
        return f.endsWith("/") ? f.substring(0, f.length() - 1) : f;
    }

    // ── Overlay ───────────────────────────────────────────────────────────────

    private void toggleControls()  { if (overlayVisible) hideControls(); else showControls(); }

    private void showControls() {
        overlayVisible = true;
        controlsOverlay.setVisibility(View.VISIBLE);
        tvTapHint.setVisibility(View.GONE);
        uiHandler.removeCallbacks(autoHide);
        uiHandler.postDelayed(autoHide, 10000);
    }

    private void hideControls() {
        overlayVisible = false;
        controlsOverlay.setVisibility(View.GONE);
        tvTapHint.setVisibility(View.VISIBLE);
        uiHandler.removeCallbacks(autoHide);
    }

    private void resetAutoHide() {
        if (overlayVisible) {
            uiHandler.removeCallbacks(autoHide);
            uiHandler.postDelayed(autoHide, 10000);
        }
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    @Override
    protected void onResume() {
        super.onResume();
        enterImmersive();
        if (streamActive) startListening();
    }

    @Override
    public void onWindowFocusChanged(boolean focus) {
        super.onWindowFocusChanged(focus);
        if (focus) enterImmersive();
    }

    @SuppressWarnings("deprecation")
    private void enterImmersive() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                getWindow().setDecorFitsSystemWindows(false);
                // Use reflection to avoid VerifyError on API < 30
                Object wic = getWindow().getClass()
                    .getMethod("getInsetsController").invoke(getWindow());
                if (wic != null) {
                    Class<?> typeCls = Class.forName("android.view.WindowInsets$Type");
                    int bars = (int) typeCls.getMethod("statusBars").invoke(null)
                             | (int) typeCls.getMethod("navigationBars").invoke(null);
                    wic.getClass().getMethod("hide", int.class).invoke(wic, bars);
                    wic.getClass().getMethod("setSystemBarsBehavior", int.class).invoke(wic, 2);
                }
            } catch (Exception e) { legacyImmersive(); }
        } else {
            legacyImmersive();
        }
    }

    private void legacyImmersive() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    // ── Live audio listen (camera mic → viewer speaker) ───────────────────────

    private void startListening() {
        if (listenRunning || controlBase == null || controlBase.isEmpty()) return;
        listenRunning = true;
        executor.submit(() -> {
            try {
                String u = controlBase + "/audio" + authSuffix("?");
                HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
                c.setConnectTimeout(5000);
                c.setReadTimeout(0); // streaming — no read timeout
                if (c.getResponseCode() != 200) { c.disconnect(); listenRunning = false; return; }
                InputStream in = c.getInputStream();
                // Skip 44-byte WAV header
                byte[] header = new byte[44];
                int read = 0;
                while (read < 44) {
                    int n = in.read(header, read, 44 - read);
                    if (n < 0) { c.disconnect(); listenRunning = false; return; }
                    read += n;
                }
                int sr = AudioStreamer.SAMPLE_RATE;
                int bs = AudioTrack.getMinBufferSize(sr,
                    AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT) * 2;
                listenTrack = new AudioTrack(AudioManager.STREAM_MUSIC, sr,
                    AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    bs, AudioTrack.MODE_STREAM);
                listenTrack.play();
                listenTrack.setVolume(isMuted ? 0f : sbListenVol.getProgress() / 100f);
                byte[] buf = new byte[4096];
                int n;
                while (listenRunning && (n = in.read(buf)) != -1) {
                    listenTrack.write(buf, 0, n);
                }
                c.disconnect();
            } catch (Exception e) {
                Log.e(TAG, "Audio listen error: " + e.getMessage());
            } finally {
                stopListening();
            }
        });
    }

    private void stopListening() {
        listenRunning = false;
        if (listenTrack != null) {
            try { listenTrack.stop(); listenTrack.release(); } catch (Exception ignored) {}
            listenTrack = null;
        }
    }

    // ── Hold-to-talk (viewer mic → camera speaker) ────────────────────────────

    @SuppressLint("MissingPermission")
    private void startTalk() {
        if (talkRunning || controlBase == null || controlBase.isEmpty()) return;
        talkRunning = true;
        btnTalk.setText("🔴");
        btnTalk.setBackgroundTintList(
            android.content.res.ColorStateList.valueOf(0xFFff3b3b));
        String wsUrl = controlBase
            .replace("http://",  "ws://")
            .replace("https://", "wss://")
            .replace(":8080", ":8081")
            .replace(":8443", ":8444");
        executor.submit(() -> {
            try {
                talkSocket = new WebSocketClient(wsUrl);
                talkSocket.connect();
                int bs = AudioRecord.getMinBufferSize(16000,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT) * 2;
                talkRecord = new AudioRecord(MediaRecorder.AudioSource.MIC,
                    16000, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, bs);
                talkRecord.startRecording();
                byte[] buf = new byte[bs];
                while (talkRunning) {
                    int r = talkRecord.read(buf, 0, buf.length);
                    if (r > 0) {
                        if (talkGain != 1.0f) {
                            // Apply gain in-place
                            short[] samples = new short[r / 2];
                            ByteBuffer.wrap(buf, 0, r).order(ByteOrder.LITTLE_ENDIAN)
                                .asShortBuffer().get(samples);
                            for (int i = 0; i < samples.length; i++) {
                                int val = (int)(samples[i] * talkGain);
                                samples[i] = (short) Math.max(-32768, Math.min(32767, val));
                            }
                            ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN)
                                .asShortBuffer().put(samples);
                        }
                        talkSocket.send(buf, r);
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "Talk error: " + e.getMessage());
            }
        });
    }

    private void stopTalk() {
        talkRunning = false;
        executor.submit(() -> {
            try {
                if (talkRecord != null) {
                    try { talkRecord.stop(); } catch (Exception ignored) {}
                    talkRecord.release(); talkRecord = null;
                }
            } catch (Exception ignored) {}
            try {
                if (talkSocket != null) { talkSocket.close(); talkSocket = null; }
            } catch (Exception ignored) {}
        });
        uiHandler.post(() -> {
            btnTalk.setText("🎤 Talk");
            btnTalk.setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(0xFF1a1430));
        });
    }

    // ── Snapshot ──────────────────────────────────────────────────────────────

    private void takeSnapshot() {
        if (controlBase == null || controlBase.isEmpty()) return;
        executor.submit(() -> {
            try {
                String u = controlBase + "/shot.jpg" + authSuffix("?");
                HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
                c.setConnectTimeout(4000);
                ByteArrayOutputStream buf = new ByteArrayOutputStream();
                byte[] b = new byte[4096]; int n;
                while ((n = c.getInputStream().read(b)) != -1) buf.write(b, 0, n);
                c.disconnect();
                String fname = "snap_" + System.currentTimeMillis() + ".jpg";
                File dir = Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_PICTURES);
                if (!dir.exists()) dir.mkdirs();
                try (FileOutputStream fos = new FileOutputStream(new File(dir, fname))) {
                    fos.write(buf.toByteArray());
                }
                uiHandler.post(() -> Toast.makeText(this,
                    "Saved to Pictures: " + fname, Toast.LENGTH_SHORT).show());
            } catch (Exception e) {
                uiHandler.post(() -> Toast.makeText(this,
                    "Snapshot failed", Toast.LENGTH_SHORT).show());
            }
        });
    }

    // ── Polling ───────────────────────────────────────────────────────────────

    private void loadCurrentState() {
        if (controlBase == null || controlBase.isEmpty()) return;
        executor.submit(() -> {
            try {
                String u = controlBase + "/state" + authSuffix("?");
                HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
                c.setConnectTimeout(5000); c.setReadTimeout(5000);
                if (c.getResponseCode() != 200) { c.disconnect(); return; }
                String body = new String(readAll(c.getInputStream())); c.disconnect();
                final boolean fr  = body.contains("\"front\":true");
                final boolean ni  = body.contains("\"night\":true");
                final boolean rec = body.contains("\"recording\":true");
                final int   q  = parseJsonInt(body,   "quality",     1);
                final int   f  = parseJsonInt(body,   "fps",        15);
                final int   fl = parseJsonInt(body,   "flash",       0);
                final int   s  = parseJsonInt(body,   "sensitivity", 4);
                final float z  = parseJsonFloat(body, "zoom",      1.0f);
                uiHandler.post(() -> {
                    frontCam = fr; nightOn = ni; recordOn = rec;
                    updateFrontBtn();
                    updateToggleBtn(btnNight,  nightOn,  "Night");
                    updateToggleBtn(btnRecord, recordOn, "Record");
                    sbZoom.setProgress(Math.round((z - 1f) * 10));
                    tvZoom.setText(String.format(Locale.US, "%.1fx", z));
                    sbMotion.setProgress(Math.max(0, s - 1));
                    tvMotionSens.setText(String.valueOf(s));
                    setSpinnerSilent(spFlash, fl, flashListener);
                    setSpinnerSilent(spQual,  q,  qualListener);
                    int fi = f == 5 ? 0 : f == 10 ? 1 : f == 30 ? 3 : 2;
                    setSpinnerSilent(spFps, fi, fpsListener);
                });
            } catch (Exception ignored) {}
        });
    }

    private void startMotionPolling() {
        if (controlBase == null || controlBase.isEmpty()) return;
        uiHandler.postDelayed(new Runnable() {
            @Override public void run() {
                if (isDestroyed()) return;
                executor.submit(() -> {
                    try {
                        String u = controlBase + "/motion" + authSuffix("?");
                        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
                        c.setConnectTimeout(2000); c.setReadTimeout(2000);
                        String body = new String(readAll(c.getInputStream())); c.disconnect();
                        boolean m = body.contains("\"motion\":true");
                        uiHandler.post(() -> tvMotion.setVisibility(m ? View.VISIBLE : View.GONE));
                    } catch (Exception ignored) {}
                });
                uiHandler.postDelayed(this, 2000);
            }
        }, 1500);
    }

    private void startStatsPolling() {
        if (controlBase == null || controlBase.isEmpty()) return;
        uiHandler.postDelayed(new Runnable() {
            @Override public void run() {
                if (isDestroyed()) return;
                executor.submit(() -> {
                    try {
                        String u = controlBase + "/device_stats" + authSuffix("?");
                        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
                        c.setConnectTimeout(2000); c.setReadTimeout(2000);
                        String body = new String(readAll(c.getInputStream())); c.disconnect();
                        float batt = parseJsonFloat(body, "battery",     -1);
                        float temp = parseJsonFloat(body, "temperature", -1);
                        boolean chg = body.contains("\"charging\":true");
                        uiHandler.post(() -> {
                            tvBattery.setText(batt >= 0
                                ? String.format(Locale.US, "\uD83D\uDD0B%.0f%%%s", batt, chg ? "\u26A1" : "")
                                : "\uD83D\uDD0B\u2013");
                            tvBattery.setTextColor(batt<20?0xFFFF4444:batt<50?0xFFFF9944:0xFF44CC44);
                            tvTemp.setText(temp >= 0
                                ? String.format(Locale.US, "\uD83C\uDF21%.1f\u00B0C", temp)
                                : "\uD83C\uDF21\u2013");
                            tvTemp.setTextColor(temp>45?0xFFFF4444:temp>38?0xFFFF9944:0xFF44CC44);
                        });
                    } catch (Exception ignored) {}
                });
                uiHandler.postDelayed(this, 8000);
            }
        }, 2000);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private void camApi(String path) {
        if (controlBase == null || controlBase.isEmpty()) return;
        executor.submit(() -> {
            try {
                String u = controlBase + path + authSuffix(path.contains("?") ? "&" : "?");
                HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
                c.setRequestMethod("GET");
                c.setConnectTimeout(4000);
                c.getResponseCode();
                c.disconnect();
            } catch (Exception e) {
                Log.e(TAG, "API error: " + e.getMessage());
            }
        });
    }

    private String authSuffix(String sep) {
        if (password == null || password.isEmpty()) return "";
        try { return sep + "auth=" + URLEncoder.encode(password, "UTF-8"); }
        catch (Exception e) { return sep + "auth=" + password; }
    }

    private void updateStreamBtn() {
        btnStream.setText(streamActive ? "\u23F9 Stream" : "\u25B6 Stream");
        btnStream.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
            streamActive ? 0xFFff3b3b : 0xFF0f4a8a));
    }

    private void updateFrontBtn() {
        Button btnFront = findViewById(R.id.btnFullFront);
        if (btnFront != null) {
            btnFront.setText(frontCam ? "Front Cam" : "Back Cam");
            btnFront.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                frontCam ? 0xFF534ab7 : 0xFF12121a));
        }
    }

    private void updateToggleBtn(Button btn, boolean on, String label) {
        btn.setText(label);
        btn.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
            on ? 0xFF00e5a0 : 0xFF12121a));
        btn.setTextColor(on ? 0xFF000000 : 0xFFe8e8f0);
    }

    private void setSpinnerSilent(Spinner sp, int pos,
                                   AdapterView.OnItemSelectedListener listener) {
        sp.setOnItemSelectedListener(null);
        if (pos >= 0 && pos < sp.getAdapter().getCount()) sp.setSelection(pos, false);
        sp.setOnItemSelectedListener(listener);
    }

    private byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        byte[] b = new byte[4096]; int n;
        while ((n = in.read(b)) != -1) buf.write(b, 0, n);
        return buf.toByteArray();
    }

    private int parseJsonInt(String json, String key, int def) {
        try {
            int i = json.indexOf("\"" + key + "\":");
            if (i < 0) return def;
            int s = i + key.length() + 3, e = s;
            while (e < json.length() && (Character.isDigit(json.charAt(e)) || json.charAt(e) == '-')) e++;
            return Integer.parseInt(json.substring(s, e));
        } catch (Exception ex) { return def; }
    }

    private float parseJsonFloat(String json, String key, float def) {
        try {
            int i = json.indexOf("\"" + key + "\":");
            if (i < 0) return def;
            int s = i + key.length() + 3, e = s;
            while (e < json.length() && (Character.isDigit(json.charAt(e))
                   || json.charAt(e) == '.' || json.charAt(e) == '-')) e++;
            return Float.parseFloat(json.substring(s, e));
        } catch (Exception ex) { return def; }
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    @Override protected void onPause()   { super.onPause();   stopListening(); }
    @Override protected void onDestroy() {
        super.onDestroy();
        stopListening();
        stopTalk();
        uiHandler.removeCallbacksAndMessages(null);
        mjpegView.stopStream();
        executor.shutdownNow();
    }

    // ── Minimal WebSocket client ──────────────────────────────────────────────

    static class WebSocketClient {
        private java.net.Socket socket;
        private OutputStream out;
        private final String url;

        WebSocketClient(String url) { this.url = url; }

        void connect() throws IOException {
            URI uri;
            try { uri = new URI(url); } catch (Exception e) { throw new IOException(e); }
            socket = new java.net.Socket(uri.getHost(), uri.getPort() > 0 ? uri.getPort() : 80);
            out = socket.getOutputStream();
            String req = "GET / HTTP/1.1\r\nHost: " + uri.getHost()
                + "\r\nUpgrade: websocket\r\nConnection: Upgrade"
                + "\r\nSec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ=="
                + "\r\nSec-WebSocket-Version: 13\r\n\r\n";
            out.write(req.getBytes()); out.flush();
            byte[] b = new byte[1024];
            int read = socket.getInputStream().read(b);
            if (read == -1) throw new IOException("WebSocket handshake failed");
        }

        void send(byte[] data, int len) throws IOException {
            byte[] mask = {0x12, 0x34, 0x56, 0x78};
            byte[] frame = len < 126 ? new byte[6 + len] : new byte[8 + len];
            frame[0] = (byte) 0x82;
            if (len < 126) {
                frame[1] = (byte)(0x80 | len);
                frame[2]=mask[0]; frame[3]=mask[1]; frame[4]=mask[2]; frame[5]=mask[3];
                for (int i = 0; i < len; i++) frame[6+i] = (byte)(data[i] ^ mask[i%4]);
            } else {
                frame[1] = (byte)(0x80 | 126);
                frame[2]=(byte)(len>>8); frame[3]=(byte)(len&0xFF);
                frame[4]=mask[0]; frame[5]=mask[1]; frame[6]=mask[2]; frame[7]=mask[3];
                for (int i = 0; i < len; i++) frame[8+i] = (byte)(data[i] ^ mask[i%4]);
            }
            out.write(frame); out.flush();
        }

        void close() { try { if (socket != null) socket.close(); } catch (Exception ignored) {} }
    }
}
