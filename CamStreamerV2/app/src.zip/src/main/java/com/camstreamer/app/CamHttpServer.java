package com.camstreamer.app;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import fi.iki.elonen.NanoHTTPD;
import java.io.*;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import javax.net.ssl.SSLServerSocketFactory;

/**
 * HTTP server.
 *
 * Fixes applied:
 *  1. Auth uses a random session token stored server-side — the raw password
 *     is no longer sent back as the cookie value.
 *  2. /motion_events — Server-Sent Events endpoint.  The web dashboard
 *     subscribes to this instead of relying on polling /motion.  The server
 *     pushes an event the instant MotionDetector fires its callback, so the
 *     browser gets notified in real time and can show an alert/sound without
 *     waiting for the next 3s poll.  This also means motion notifications go
 *     to the web dashboard / viewer, not only to the server device.
 *  3. CORS restricted to same-host for mutation endpoints.
 *  4. StreamingService.instance null-checks tightened throughout.
 *  5. getEventCount() now uses long.
 */
public class CamHttpServer extends NanoHTTPD {

    private static final String TAG = "CamHttpServer";

    public static final String ACTION_UPDATE_UI = "com.camstreamer.app.UPDATE_UI";

    private final Context          context;
    private final CameraController camera;
    private final AudioStreamer    audio;
    private final MotionDetector   motion;
    private final TwoWayAudio      twoWay;
    private final String           password;
    private final int              httpsPort;

    // Session tokens: token → creation-time (simple in-memory store, cleared on stop)
    private final Map<String, Long> sessions = Collections.synchronizedMap(new LinkedHashMap<>());

    // SSE clients waiting for motion events
    private final CopyOnWriteArrayList<OutputStream> sseClients = new CopyOnWriteArrayList<>();

    private NanoHTTPD httpsServer = null;

    public CamHttpServer(Context ctx, int httpPort, int httpsPort,
                         CameraController cam, AudioStreamer aud,
                         MotionDetector mot, TwoWayAudio tw, String pw) {
        super(httpPort);
        this.httpsPort = httpsPort;
        context  = ctx; camera = cam; audio = aud;
        motion   = mot; twoWay = tw;
        password = (pw != null) ? pw.trim() : "";

        // Register motion listener — fires on camera thread, pushes SSE to browser
        motion.setMotionListener(this::pushMotionEvent);
    }

    /** Called by MotionDetector on rising edge — push SSE to all subscribed browsers. */
    private void pushMotionEvent() {
        String event = "event: motion\ndata: {\"motion\":true,\"ts\":" +
            System.currentTimeMillis() + "}\n\n";
        byte[] bytes = event.getBytes();
        List<OutputStream> dead = new ArrayList<>();
        for (OutputStream out : sseClients) {
            try {
                out.write(bytes);
                out.flush();
            } catch (IOException e) {
                dead.add(out);
            }
        }
        sseClients.removeAll(dead);
    }

    public void start() {
        try { start(NanoHTTPD.SOCKET_READ_TIMEOUT, false); }
        catch (IOException e) { e.printStackTrace(); }
        startHttpsServer();
    }

    private void startHttpsServer() {
        SSLServerSocketFactory sslFactory = SslHelper.getFactory(context);
        if (sslFactory == null) {
            Log.e(TAG, "SSL factory null — HTTPS will not start.");
            return;
        }
        httpsServer = new NanoHTTPD(httpsPort) {
            @Override
            public Response serve(IHTTPSession session) {
                return CamHttpServer.this.serve(session);
            }
        };
        try {
            httpsServer.makeSecure(sslFactory, null);
            httpsServer.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false);
            Log.i(TAG, "HTTPS server started on port " + httpsPort);
        } catch (IOException e) {
            Log.e(TAG, "HTTPS server failed: " + e.getMessage());
        }
    }

    @Override
    public void stop() {
        super.stop();
        if (httpsServer != null) { httpsServer.stop(); httpsServer = null; }
        sessions.clear();
        // Close all SSE connections
        for (OutputStream out : sseClients) {
            try { out.close(); } catch (IOException ignored) {}
        }
        sseClients.clear();
    }

    // ── Auth helpers ─────────────────────────────────────────────────────────

    private String newSessionToken() {
        String token = UUID.randomUUID().toString();
        sessions.put(token, System.currentTimeMillis());
        // Evict tokens older than 24h
        long cutoff = System.currentTimeMillis() - 86_400_000L;
        sessions.entrySet().removeIf(e -> e.getValue() < cutoff);
        return token;
    }

    private boolean isAuthorized(IHTTPSession session, Map<String, String> params) {
        if (password.isEmpty()) return true;
        String cookie = session.getCookies().read("auth_token");
        if (cookie != null && sessions.containsKey(cookie)) return true;
        // Allow token in query param for non-browser clients (stream URLs etc.)
        String qToken = params.getOrDefault("auth", "");
        return password.equals(qToken);
    }

    @Override
    public Response serve(IHTTPSession session) {
        String uri    = session.getUri();
        Map<String, String> params = session.getParms();

        // Auth — exempt login page and root redirect
        if (!uri.equals("/login") && !uri.equals("/")) {
            if (!isAuthorized(session, params)) {
                return withCors(newFixedLengthResponse(Response.Status.UNAUTHORIZED,
                    "application/json", "{\"error\":\"unauthorized\"}"));
            }
        }

        switch (uri) {
            case "/video":          return withCors(serveMjpeg());
            case "/shot.jpg":       return withCors(serveSnapshot());
            case "/audio":          return withCors(serveAudio());
            case "/motion":         return withCors(serveMotion());
            case "/motion_events":  return serveMotionEvents();   // SSE — no CORS wildcard needed
            case "/config":         return withCors(serveConfig(params));
            case "/flash":          return withCors(serveFlash(params));
            case "/zoom":           return withCors(serveZoom(params));
            case "/camera":         return withCors(serveCamera(params));
            case "/toggle_stream":  return withCors(serveToggleStream(params));
            case "/device_stats":   return withCors(serveDeviceStats());
            case "/state":          return withCors(serveState());
            case "/focus":
                camera.triggerAutoFocus();
                return withCors(json("{\"focus\":\"triggered\"}"));
            case "/dvr":            return withCors(serveDvr(params));
            case "/dvr_files":      return withCors(serveDvrFiles());
            case "/playback":       return servePlayback(session, params);
            case "/login":          return withCors(serveLogin(params));
            case "/status":         return withCors(serveStatus());
            default:                return withCors(serveDashboard());
        }
    }

    // ── /motion_events — Server-Sent Events ───────────────────────────────────
    //
    // The browser connects once and keeps the connection open.
    // Whenever MotionDetector fires, pushMotionEvent() writes an SSE message
    // to every subscribed OutputStream here.  The browser JS listens with
    // EventSource('/motion_events') and shows the alert immediately.

    private Response serveMotionEvents() {
        PipedOutputStream out = new PipedOutputStream();
        PipedInputStream  in;
        try { in = new PipedInputStream(out, 64 * 1024); }
        catch (IOException e) { return err("SSE init failed"); }

        sseClients.add(out);

        // Send a comment heartbeat every 25s to keep the connection alive
        // (the browser EventSource will reconnect automatically if it drops)
        new Thread(() -> {
            try {
                // Initial connected event
                out.write("event: connected\ndata: {}\n\n".getBytes());
                out.flush();
                while (!Thread.interrupted()) {
                    Thread.sleep(25_000);
                    out.write(": heartbeat\n\n".getBytes());
                    out.flush();
                }
            } catch (Exception e) {
                sseClients.remove(out);
                try { out.close(); } catch (IOException ignored) {}
            }
        }, "SseHeartbeat").start();

        Response r = newChunkedResponse(Response.Status.OK, "text/event-stream", in);
        r.addHeader("Cache-Control", "no-cache");
        r.addHeader("X-Accel-Buffering", "no");
        r.addHeader("Access-Control-Allow-Origin", "*");
        return r;
    }

    // ── /state ────────────────────────────────────────────────────────────────

    private Response serveState() {
        StreamingService svc = StreamingService.instance;
        boolean streaming   = svc != null && svc.isStreamingActive();
        boolean recording   = svc != null && svc.isRecording();
        boolean dashRunning = svc != null && svc.isDashboardRunning();
        boolean dvr         = svc != null && svc.isDvrRunning;

        return json(String.format(Locale.US,
            "{\"streaming\":%b,\"recording\":%b,\"dashboard\":%b,\"dvr\":%b," +
            "\"quality\":%d,\"fps\":%d,\"flash\":%d," +
            "\"zoom\":%.1f,\"front\":%b,\"night\":%b,\"sensitivity\":%d}",
            streaming, recording, dashRunning, dvr,
            camera.getQualityIndex(), camera.getFps(), camera.getFlashMode(),
            camera.getZoomLevel(), camera.isFrontCamera(), camera.isNightMode(),
            motion.getSensitivity()));
    }

    // ── /status ───────────────────────────────────────────────────────────────

    private Response serveStatus() {
        StreamingService svc = StreamingService.instance;
        return json("{\"recording\":"    + (svc != null && svc.isRecording()) +
            ",\"streaming\":"            + (svc != null && svc.isStreamingActive()) +
            ",\"passwordProtected\":"    + !password.isEmpty() + "}");
    }

    // ── /toggle_stream ────────────────────────────────────────────────────────

    private Response serveToggleStream(Map<String, String> p) {
        boolean start = "1".equals(p.get("active"));
        StreamingService svc = StreamingService.instance;
        if (svc != null) {
            svc.toggleStreaming(start);
            notifyUi("streaming", start ? "1" : "0");
        }
        return json("{\"ok\":true,\"streaming\":" + start + "}");
    }

    // ── /device_stats ─────────────────────────────────────────────────────────

    private Response serveDeviceStats() {
        StreamingService svc = StreamingService.instance;
        float batt    = svc != null ? svc.getBatteryLevel() : -1;
        float temp    = svc != null ? svc.getTemperature()  : -1;
        boolean charg = svc != null && svc.isCharging();
        return json(String.format(Locale.US,
            "{\"battery\":%.1f,\"temperature\":%.1f,\"charging\":%b}",
            batt, temp, charg));
    }

    // ── /video — MJPEG ────────────────────────────────────────────────────────

    private Response serveMjpeg() {
        StreamingService svc = StreamingService.instance;
        if (svc == null || !svc.isStreamingActive())
            return err("Streaming is not active.");

        PipedOutputStream out = new PipedOutputStream();
        PipedInputStream  in;
        try { in = new PipedInputStream(out, 512 * 1024); }
        catch (IOException e) { return err("Stream init failed"); }

        new Thread(() -> {
            try {
                while (!Thread.interrupted()) {
                    camera.waitForNewFrame(200);
                    if (!camera.hasFrame()) continue;
                    byte[] frame = camera.getLatestFrame();
                    String header = "--frame\r\nContent-Type: image/jpeg\r\n" +
                        "Content-Length: " + frame.length + "\r\n\r\n";
                    out.write(header.getBytes());
                    out.write(frame);
                    out.write("\r\n".getBytes());
                    out.flush();
                }
            } catch (Exception e) {
                try { out.close(); } catch (IOException ignored) {}
            }
        }, "MjpegWriter").start();

        // newChunkedResponse is correct here — chunked transfer encoding works fine
        // for multipart/x-mixed-replace in all browsers. The previous switch to
        // newFixedLengthResponse(..., -1) was wrong: NanoHTTPD writes a literal
        // "Content-Length: -1" header which browsers reject, showing alt text.
        return newChunkedResponse(Response.Status.OK,
            "multipart/x-mixed-replace; boundary=frame", in);
    }

    private Response serveSnapshot() {
        if (!camera.hasFrame()) return err("No frame yet");
        byte[] f = camera.getLatestFrame();
        return newFixedLengthResponse(Response.Status.OK, "image/jpeg",
            new ByteArrayInputStream(f), f.length);
    }

    private Response serveAudio() {
        if (audio == null) return err("Audio not available");
        InputStream s = audio.getStream();
        if (s == null) return err("Not ready");
        return newChunkedResponse(Response.Status.OK, "audio/wav", s);
    }

    private Response serveMotion() {
        return json("{\"motion\":"    + motion.isMotionDetected() +
            ",\"sensitivity\":"       + motion.getSensitivity()   +
            ",\"events\":"            + motion.getEventCount()    +
            ",\"lastSeen\":"          + motion.getLastMotionTime() + "}");
    }

    // ── /config ───────────────────────────────────────────────────────────────

    private Response serveConfig(Map<String, String> p) {
        if (p.containsKey("quality")) {
            int q = parseInt(p.get("quality"), 1);
            camera.setQuality(q); notifyUi("quality", String.valueOf(q));
        }
        if (p.containsKey("fps")) {
            int f = parseInt(p.get("fps"), 15);
            camera.setFps(f); notifyUi("fps", String.valueOf(f));
        }
        if (p.containsKey("flash")) {
            int f = parseInt(p.get("flash"), 0);
            camera.setFlashMode(f); notifyUi("flash", String.valueOf(f));
        }
        if (p.containsKey("zoom")) {
            float z = parseFloat(p.get("zoom"), 1f);
            camera.setZoom(z); notifyUi("zoom", String.valueOf(z));
        }
        if (p.containsKey("front")) {
            boolean f = "1".equals(p.get("front"));
            camera.switchCamera(f); notifyUi("front", f ? "1" : "0");
        }
        if (p.containsKey("sensitivity")) {
            int s = parseInt(p.get("sensitivity"), 4);
            motion.setSensitivity(s); notifyUi("sensitivity", String.valueOf(s));
        }
        if (p.containsKey("night")) {
            boolean n = "1".equals(p.get("night"));
            camera.setNightMode(n); notifyUi("night", n ? "1" : "0");
        }
        if (p.containsKey("record")) {
            boolean r = "1".equals(p.get("record"));
            StreamingService svc = StreamingService.instance;
            if (svc != null) svc.setRecording(r);
            notifyUi("record", r ? "1" : "0");
        }
        if (p.containsKey("dvr")) {
            boolean d = "1".equals(p.get("dvr"));
            StreamingService svc2 = StreamingService.instance;
            if (svc2 != null) svc2.setDvr(d);
            notifyUi("dvr", d ? "1" : "0");
        }
        if (p.containsKey("motion_notif")) {
            notifyUi("motion_notif", p.get("motion_notif"));
        }
        return json("{\"ok\":true}");
    }

    private Response serveFlash(Map<String, String> p) {
        String mode = p.getOrDefault("mode", "off");
        int m = "torch".equals(mode) ? CameraController.FLASH_TORCH
              : "auto".equals(mode)  ? CameraController.FLASH_AUTO
              : CameraController.FLASH_OFF;
        camera.setFlashMode(m); notifyUi("flash", String.valueOf(m));
        return json("{\"flash\":\"" + mode + "\"}");
    }

    private Response serveZoom(Map<String, String> p) {
        float z = Math.max(1f, Math.min(10f,
            parseFloat(p.getOrDefault("level", "1"), 1f)));
        camera.setZoom(z); notifyUi("zoom", String.valueOf(z));
        return json("{\"zoom\":" + z + "}");
    }

    private Response serveCamera(Map<String, String> p) {
        boolean front = "front".equalsIgnoreCase(p.getOrDefault("facing", "back"));
        camera.switchCamera(front); notifyUi("front", front ? "1" : "0");
        return json("{\"camera\":\"" + (front ? "front" : "back") + "\"}");
    }

    // ── /login — issues a random session token, never sends the password back ─

    private Response serveLogin(Map<String, String> p) {
        String pw = p.getOrDefault("pw", "");
        if (password.isEmpty() || password.equals(pw)) {
            String token = newSessionToken();
            Response r = json("{\"ok\":true}");
            // HttpOnly + SameSite=Strict keeps the token off the network
            r.addHeader("Set-Cookie",
                "auth_token=" + token + "; Path=/; HttpOnly; SameSite=Strict");
            return r;
        }
        return withCors(newFixedLengthResponse(Response.Status.UNAUTHORIZED,
            "application/json", "{\"ok\":false,\"error\":\"wrong password\"}"));
    }


    // ── /dvr ─────────────────────────────────────────────────────────────────

    private Response serveDvr(Map<String, String> p) {
        boolean on = "1".equals(p.get("active"));
        StreamingService svc = StreamingService.instance;
        if (svc != null) { svc.setDvr(on); notifyUi("dvr", on ? "1" : "0"); }
        return json("{\"ok\":true,\"dvr\":" + on + "}");
    }

    // ── /dvr_files ────────────────────────────────────────────────────────────

    private Response serveDvrFiles() {
        StreamingService svc = StreamingService.instance;
        if (svc == null) return json("{\"files\":[]}");
        java.util.List<java.io.File> files = svc.getDvrFiles();
        StringBuilder sb = new StringBuilder("{\"files\":[");
        for (int i = 0; i < files.size(); i++) {
            java.io.File f = files.get(i);
            if (i > 0) sb.append(',');
            sb.append("{\"name\":\"").append(f.getName())
              .append("\",\"size\":").append(f.length())
              .append(",\"ts\":").append(f.lastModified()).append("}");
        }
        sb.append("]}");
        return json(sb.toString());
    }

    // ── /playback ─────────────────────────────────────────────────────────────

    /**
     * Serve an MP4 file with HTTP Range support.
     * Without Range responses the browser video element cannot seek — it would
     * need to download the entire file before playing because the MP4 moov atom
     * (metadata) is at the end of MediaRecorder-produced files.
     * With Range support the browser can request just the moov atom first, then
     * seek to any position by requesting the relevant byte range.
     */
    private Response servePlayback(IHTTPSession session, Map<String, String> p) {
        String name = p.getOrDefault("file", "");
        if (name.isEmpty() || name.contains("..") || name.contains("/"))
            return err("Invalid filename");
        StreamingService svc = StreamingService.instance;
        if (svc == null) return err("Service not running");
        java.io.File f = new java.io.File(svc.getRecordingDir(), name);
        if (!f.exists() || !f.isFile()) return err("File not found");

        long fileLen = f.length();
        String rangeHeader = session.getHeaders().get("range");

        try {
            long start = 0, end = fileLen - 1;
            Response.Status status = Response.Status.OK;

            if (rangeHeader != null && rangeHeader.startsWith("bytes=")) {
                // Parse "bytes=start-end" or "bytes=start-"
                String range = rangeHeader.substring(6);
                String[] parts = range.split("-", -1);
                try {
                    if (!parts[0].isEmpty()) start = Long.parseLong(parts[0]);
                    if (parts.length > 1 && !parts[1].isEmpty()) end = Long.parseLong(parts[1]);
                    else end = fileLen - 1;
                } catch (NumberFormatException ignored) {}
                if (start >= fileLen) return err("Range Not Satisfiable");
                end = Math.min(end, fileLen - 1);
                status = Response.Status.PARTIAL_CONTENT;
            }

            long contentLen = end - start + 1;
            java.io.RandomAccessFile raf = new java.io.RandomAccessFile(f, "r");
            raf.seek(start);

            // Wrap RandomAccessFile as InputStream for NanoHTTPD
            java.io.InputStream is = new java.io.InputStream() {
                @Override public int read() throws java.io.IOException {
                    return raf.read();
                }
                @Override public int read(byte[] b, int off, int len) throws java.io.IOException {
                    return raf.read(b, off, len);
                }
                @Override public void close() throws java.io.IOException {
                    raf.close();
                }
            };

            Response r = newFixedLengthResponse(status, "video/mp4", is, contentLen);
            r.addHeader("Accept-Ranges",  "bytes");
            r.addHeader("Content-Length", String.valueOf(contentLen));
            if (status == Response.Status.PARTIAL_CONTENT) {
                r.addHeader("Content-Range",
                    "bytes " + start + "-" + end + "/" + fileLen);
            }
            r.addHeader("Content-Disposition", "inline; filename=\"" + name + "\"");
            r.addHeader("Access-Control-Allow-Origin", "*");
            return r;

        } catch (java.io.IOException e) {
            return err("IO error: " + e.getMessage());
        }
    }

    // ── notifyUi ─────────────────────────────────────────────────────────────

    public void notifyUi(String key, String val) {
        Intent intent = new Intent(ACTION_UPDATE_UI);
        intent.setPackage(context.getPackageName());
        intent.putExtra("key", key);
        intent.putExtra("val", val);
        context.sendBroadcast(intent);
    }

    private Response serveDashboard() {
        return newFixedLengthResponse(Response.Status.OK, "text/html",
            WebDashboard.getHtml(password));
    }

    private Response json(String body) {
        return newFixedLengthResponse(Response.Status.OK, "application/json", body);
    }
    private Response err(String msg) {
        return newFixedLengthResponse(Response.Status.INTERNAL_ERROR, "text/plain", msg);
    }
    private Response withCors(Response r) {
        r.addHeader("Access-Control-Allow-Origin",  "*");
        r.addHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        r.addHeader("Cache-Control", "no-cache");
        return r;
    }
    private int   parseInt(String s, int d)     {
        try { return Integer.parseInt(s); } catch (Exception e) { return d; }
    }
    private float parseFloat(String s, float d) {
        try { return Float.parseFloat(s); } catch (Exception e) { return d; }
    }
}
