package com.camstreamer.app;

import android.app.*;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ServiceInfo;
import android.media.*;
import android.os.*;
import android.os.Environment;
import android.util.Log;
import android.view.Surface;
import androidx.core.app.NotificationCompat;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Foreground service owning camera, audio, and HTTP server.
 *
 * WHY MediaRecorder instead of MediaCodec?
 * ─────────────────────────────────────────
 * MediaCodec + software JPEG→NV12 conversion per frame:
 *   • Allocates ~1.7 MB of heap per frame (int[] argb + byte[] nv12 + Bitmap)
 *   • At 15fps that is ~25 MB/s of allocation → GC pressure → OOM crash within
 *     seconds on mid-range devices
 *   • Two threads sharing a MediaMuxer require careful locking; any mistake
 *     causes IllegalStateException or deadlock
 *
 * MediaRecorder + VideoSource.SURFACE:
 *   • Camera ISP writes directly to the encoder surface — zero heap allocation
 *     per frame in the recording path
 *   • Audio is captured by MediaRecorder's own internal thread — no AudioRecord
 *     conflict because MediaRecorder uses a separate AudioRecord session that
 *     Android allows concurrently with our AudioStreamer
 *   • Proven to produce playable MP4 files on all tested devices
 *   • Stable, no threading complexity
 *
 * The timestamp overlay is visible on the live MJPEG stream (burned by
 * CameraController.stampTimestamp) and in the recording filename.
 *
 * DVR: same MediaRecorder pipeline, looped with a timed stop.
 * Each segment is a fresh MediaRecorder instance.
 */
public class StreamingService extends Service {

    private static final String TAG = "StreamingService";

    public static StreamingService instance;
    public static final String ACTION_STOP_SERVICE = "com.camstreamer.app.STOP_SERVICE";
    public static final String ACTION_STOP_STREAM  = "com.camstreamer.app.STOP_STREAM";

    public CameraController cameraController;
    public MotionDetector   motionDetector;
    public AudioStreamer    audioStreamer;
    public TwoWayAudio      twoWayAudio;
    public CamHttpServer    httpServer;

    private static final String CHANNEL_ID = "CamStreamerSvc";
    private static final int    PORT_HTTP  = 8080;
    private static final int    PORT_HTTPS = 8443;
    private static final int    PORT_WS    = 8081;
    private static final int    PORT_WSS   = 8444;

    public static final int DVR_SEGMENT_MINUTES = 5;
    public static final int DVR_KEEP_SEGMENTS   = 12;   // 60 min total

    // ── Recording state ───────────────────────────────────────────────────────
    private MediaRecorder    mediaRecorder;
    private volatile boolean isRecording   = false;
    private String           currentRecPath;

    // ── DVR state ─────────────────────────────────────────────────────────────
    public  volatile boolean isDvrRunning  = false;
    private volatile boolean dvrStopFlag   = false;
    private Thread           dvrThread;

    private boolean isDashboardRunning = false;
    private boolean isStreamingActive  = false;
    private String  streamPassword     = "";

    private final Handler  notifHandler = new Handler(Looper.getMainLooper());
    private final Runnable notifUpdater = new Runnable() {
        @Override public void run() {
            updateNotificationWithStats();
            notifHandler.postDelayed(this, 10_000);
        }
    };

    // ── Service lifecycle ─────────────────────────────────────────────────────

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String action = intent.getAction();
            if (ACTION_STOP_SERVICE.equals(action)) {
                stopSelf(); return START_NOT_STICKY;
            }
            if (ACTION_STOP_STREAM.equals(action)) {
                toggleStreaming(false);
                toggleDashboard(false);
                Intent ui = new Intent(CamHttpServer.ACTION_UPDATE_UI);
                ui.setPackage(getPackageName());
                ui.putExtra("key", "streaming"); ui.putExtra("val", "0");
                sendBroadcast(ui);
                return START_STICKY;
            }
        }
        instance = this;
        if (intent != null && intent.hasExtra("password"))
            streamPassword = intent.getStringExtra("password");
        if (streamPassword == null) streamPassword = "";

        createNotificationChannel();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            startForeground(1, buildNotification("Service ready\u2026"),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA |
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(1, buildNotification("Service ready\u2026"),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA);
        } else {
            startForeground(1, buildNotification("Service ready\u2026"));
        }
        notifHandler.postDelayed(notifUpdater, 5_000);
        return START_STICKY;
    }

    // ── Dashboard / streaming ─────────────────────────────────────────────────

    public void toggleDashboard(boolean start) {
        if (start && !isDashboardRunning) {
            try {
                if (motionDetector   == null) motionDetector   = new MotionDetector();
                if (cameraController == null) cameraController = new CameraController(this, motionDetector);
                if (audioStreamer    == null) { audioStreamer = new AudioStreamer(); audioStreamer.start(); }
                if (twoWayAudio     == null) { twoWayAudio = new TwoWayAudio(PORT_WS, PORT_WSS, this); twoWayAudio.start(); }
                if (httpServer      == null) {
                    httpServer = new CamHttpServer(this, PORT_HTTP, PORT_HTTPS,
                        cameraController, audioStreamer, motionDetector, twoWayAudio, streamPassword);
                    httpServer.start();
                }
                isDashboardRunning = true;
            } catch (Exception e) { e.printStackTrace(); }
        } else if (!start && isDashboardRunning) {
            if (httpServer  != null) { httpServer.stop();  httpServer  = null; }
            if (twoWayAudio != null) { twoWayAudio.stop(); twoWayAudio = null; }
            isDashboardRunning = false;
        }
        updateNotificationWithStats();
    }

    public void toggleStreaming(boolean start) {
        if (start && !isStreamingActive) {
            if (motionDetector   == null) motionDetector   = new MotionDetector();
            if (cameraController == null) cameraController = new CameraController(this, motionDetector);
            if (audioStreamer    == null) { audioStreamer = new AudioStreamer(); audioStreamer.start(); }
            cameraController.startCamera();
            isStreamingActive = true;
        } else if (!start && isStreamingActive) {
            if (isDvrRunning) stopDvr();
            if (isRecording)  stopRecording();
            if (cameraController != null) cameraController.stopCamera();
            if (audioStreamer    != null) { audioStreamer.stop(); audioStreamer = null; }
            isStreamingActive = false;
        }
        updateNotificationWithStats();
    }

    public boolean isDashboardRunning() { return isDashboardRunning; }
    public boolean isStreamingActive()  { return isStreamingActive; }

    // ── Battery / Temperature / Charging ─────────────────────────────────────

    public float getBatteryLevel() {
        Intent i = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (i == null) return -1;
        int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
        return (level < 0 || scale <= 0) ? -1 : (level / (float) scale) * 100f;
    }
    public float getTemperature() {
        Intent i = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (i == null) return -1;
        return i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0f;
    }
    public boolean isCharging() {
        Intent i = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (i == null) return false;
        int status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        return status == BatteryManager.BATTERY_STATUS_CHARGING
            || status == BatteryManager.BATTERY_STATUS_FULL;
    }

    // ── Manual recording ──────────────────────────────────────────────────────

    public void setRecording(boolean on) {
        if (on && !isRecording) startRecording("rec_");
        else if (!on && isRecording) stopRecording();
    }
    public boolean isRecording() { return isRecording; }

    // ── DVR ───────────────────────────────────────────────────────────────────

    public void setDvr(boolean on) {
        if (on && !isDvrRunning) startDvr();
        else if (!on && isDvrRunning) stopDvr();
    }

    private void startDvr() {
        if (!isStreamingActive || cameraController == null) return;
        dvrStopFlag  = false;
        isDvrRunning = true;

        dvrThread = new Thread(() -> {
            while (!dvrStopFlag && isStreamingActive) {
                // Start one segment
                startRecording("dvr_");

                // Wait for recorder to actually start (up to 3s)
                long t0 = System.currentTimeMillis();
                while (!isRecording && !dvrStopFlag
                        && System.currentTimeMillis() - t0 < 3_000) {
                    try { Thread.sleep(100); } catch (InterruptedException ignored) {}
                }

                // Run for DVR_SEGMENT_MINUTES, checking every second
                long segEnd = System.currentTimeMillis()
                    + (long) DVR_SEGMENT_MINUTES * 60_000L;
                while (!dvrStopFlag && isStreamingActive
                        && System.currentTimeMillis() < segEnd) {
                    try { Thread.sleep(1_000); } catch (InterruptedException ignored) {}
                }

                // Stop segment and wait for clean release (up to 3s)
                stopRecording();
                long t1 = System.currentTimeMillis();
                while (isRecording && System.currentTimeMillis() - t1 < 3_000) {
                    try { Thread.sleep(100); } catch (InterruptedException ignored) {}
                }

                if (!dvrStopFlag) pruneOldDvrFiles();
            }
            isDvrRunning = false;
            updateNotificationWithStats();
        }, "DvrLoop");
        dvrThread.setDaemon(true);
        dvrThread.start();
        updateNotificationWithStats();
    }

    private void stopDvr() {
        dvrStopFlag  = true;
        isDvrRunning = false;
        if (isRecording) stopRecording();
        updateNotificationWithStats();
    }

    public List<File> getDvrFiles() {
        File dir = getRecordingDir();
        File[] files = dir.listFiles(
            f -> f.getName().startsWith("dvr_") && f.getName().endsWith(".mp4"));
        if (files == null) return Collections.emptyList();
        Arrays.sort(files, Comparator.comparingLong(File::lastModified).reversed());
        return Arrays.asList(files);
    }

    private void pruneOldDvrFiles() {
        File dir = getRecordingDir();
        File[] files = dir.listFiles(
            f -> f.getName().startsWith("dvr_") && f.getName().endsWith(".mp4"));
        if (files == null || files.length <= DVR_KEEP_SEGMENTS) return;
        Arrays.sort(files, Comparator.comparingLong(File::lastModified));
        for (int i = 0; i < files.length - DVR_KEEP_SEGMENTS; i++) {
            files[i].delete();
            Log.d(TAG, "Pruned: " + files[i].getName());
        }
    }

    // ── MediaRecorder recording ───────────────────────────────────────────────
    //
    // Runs on a background thread so prepare() and the 600ms Camera2 session
    // rebuild don't block the caller.
    //
    // Order required by Android docs:
    //   setAudioSource → setVideoSource → setOutputFormat →
    //   setVideoEncoder → setAudioEncoder → setVideoSize →
    //   setVideoFrameRate → setVideoEncodingBitRate →
    //   setAudioSamplingRate → setAudioEncodingBitRate →
    //   setOutputFile → prepare() → getSurface() → start()

    private void startRecording(String prefix) {
        if (!isStreamingActive || cameraController == null) return;
        if (isRecording) return;

        new Thread(() -> {
            try {
                // Build output path
                String ts = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
                currentRecPath = new File(getRecordingDir(), prefix + ts + ".mp4")
                    .getAbsolutePath();

                // Create MediaRecorder
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    mediaRecorder = new MediaRecorder(StreamingService.this);
                } else {
                    //noinspection deprecation
                    mediaRecorder = new MediaRecorder();
                }

                mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
                mediaRecorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
                mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
                mediaRecorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
                mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
                mediaRecorder.setVideoSize(640, 480);
                mediaRecorder.setVideoFrameRate(15);
                mediaRecorder.setVideoEncodingBitRate(1_000_000);
                mediaRecorder.setAudioSamplingRate(AudioStreamer.SAMPLE_RATE);
                mediaRecorder.setAudioEncodingBitRate(64_000);
                mediaRecorder.setOutputFile(currentRecPath);
                mediaRecorder.prepare();

                // Wire recorder surface into Camera2 session
                Surface recSurface = mediaRecorder.getSurface();
                cameraController.setRecorderSurface(recSurface);

                // Give Camera2 session time to rebuild with the new surface target
                Thread.sleep(600);

                mediaRecorder.start();
                isRecording = true;
                Log.i(TAG, "Recording started: " + currentRecPath);
                updateNotificationWithStats();

            } catch (Exception e) {
                Log.e(TAG, "startRecording failed: " + e.getMessage(), e);
                isRecording = false;
                releaseRecorder(false);
                if (cameraController != null) cameraController.clearRecorderSurface();
            }
        }, "RecStart").start();
    }

    private void stopRecording() {
        // Stop on a background thread — stop() can block briefly
        final String pathToScan = currentRecPath;
        new Thread(() -> {
            releaseRecorder(true);
            if (cameraController != null) cameraController.clearRecorderSurface();
            if (pathToScan != null)
                MediaScannerConnection.scanFile(StreamingService.this,
                    new String[]{pathToScan}, null, null);
            isRecording = false;
            updateNotificationWithStats();
            Log.i(TAG, "Recording stopped: " + pathToScan);
        }, "RecStop").start();
    }

    private void releaseRecorder(boolean callStop) {
        if (mediaRecorder == null) return;
        try {
            if (callStop) mediaRecorder.stop();
        } catch (Exception e) {
            // stop() throws if no frames were recorded — delete partial file
            Log.w(TAG, "MediaRecorder.stop() error (no frames?): " + e.getMessage());
            if (currentRecPath != null) new File(currentRecPath).delete();
            currentRecPath = null;
        }
        try { mediaRecorder.reset();   } catch (Exception ignored) {}
        try { mediaRecorder.release(); } catch (Exception ignored) {}
        mediaRecorder = null;
    }

    // ── File helpers ──────────────────────────────────────────────────────────

    public File getRecordingDir() {
        File dir = new File(Environment.getExternalStoragePublicDirectory(
            Environment.DIRECTORY_MOVIES), "CamStreamer");
        if (!dir.exists() && !dir.mkdirs()) {
            dir = new File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "CamStreamer");
            dir.mkdirs();
        }
        return dir;
    }

    // ── Notification ─────────────────────────────────────────────────────────

    void updateNotificationWithStats() {
        float batt = getBatteryLevel(), temp = getTemperature();
        boolean charging = isCharging();
        String battStr = batt >= 0
            ? String.format(Locale.US, "%.0f%%%s", batt, charging ? "\u26A1" : "") : "\u2013";
        String tempStr = temp >= 0
            ? String.format(Locale.US, "%.1f\u00B0C", temp) : "\u2013";
        String state;
        if (isRecording && isDvrRunning)                  state = "\u25CF REC+DVR";
        else if (isRecording)                             state = "\u25CF REC";
        else if (isDvrRunning)                            state = "\u25CF DVR";
        else if (isStreamingActive && isDashboardRunning) state = "Stream+Web";
        else if (isStreamingActive)                       state = "Streaming";
        else if (isDashboardRunning)                      state = "Web Dashboard";
        else                                              state = "Idle";
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null)
            nm.notify(1, buildNotification(
                state + "  \uD83D\uDD0B" + battStr + "  " + tempStr));
    }

    private Notification buildNotification(String text) {
        PendingIntent open = PendingIntent.getActivity(this, 0,
            new Intent(this, MainActivity.class)
                .setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stopStream = PendingIntent.getService(this, 2,
            new Intent(this, StreamingService.class).setAction(ACTION_STOP_STREAM),
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop = PendingIntent.getService(this, 1,
            new Intent(this, StreamingService.class).setAction(ACTION_STOP_SERVICE),
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.Builder b = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("CamStreamer").setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentIntent(open)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true);
        if (isStreamingActive || isDashboardRunning)
            b.addAction(android.R.drawable.ic_media_pause, "Stop Stream", stopStream);
        b.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop Server", stop);
        return b.build();
    }

    @Override
    public void onDestroy() {
        notifHandler.removeCallbacks(notifUpdater);
        instance = null;
        if (isDvrRunning) stopDvr();
        if (isRecording)  stopRecording();
        if (httpServer       != null) httpServer.stop();
        if (twoWayAudio      != null) twoWayAudio.stop();
        if (audioStreamer    != null) audioStreamer.stop();
        if (cameraController != null) cameraController.release();
        super.onDestroy();
    }

    @Override public android.os.IBinder onBind(Intent i) { return null; }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID, "CamStreamer Service", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE))
                .createNotificationChannel(ch);
        }
    }
}
